
import { Agent, AgentStatus, AgentRoleType, AutonomousConfig, AgentCapability, AgentTier, AgentCategory } from './types';

// Safe environment variable getter for both Node and Vite environments
const getEnvVar = (key: string, defaultValue?: string): string | undefined => {
  if (typeof process !== 'undefined' && process.env) {
    if (process.env[key] !== undefined) return process.env[key];
  }
  if (typeof import.meta !== 'undefined' && (import.meta as any).env) {
    if ((import.meta as any).env[key] !== undefined) return (import.meta as any).env[key];
  }
  return defaultValue;
};

// The "Hero" Agents are explicitly defined.
// The Orchestrator will generate the remaining "Worker" drones to reach 131 total.

export const ZOMBIE_THRESHOLD = 2 * 60 * 1000; // 2 Minutes (Optimized for Service Heartbeat)
export const KERNEL_COMPLEXITY_THRESHOLD = 0.7; // 0.0 - 1.0 (Low - High complexity)

// --- PROTOCOL CLASSIFICATION FOR SMART NOTIFICATIONS ---
// Informative: Routine events that should ONLY go to System Logs (no UI re-renders)
export const INFORMATIVE_PROTOCOLS = [
  'PROTOCOL_WORKFLOW_UPDATE',        // Status: STABLE (every heartbeat)
  'PROTOCOL_VISUAL_REQUEST',         // Throttled visual capture request
  'PROTOCOL_HIVE_MIND_SYNC',         // Background sync
  'PROTOCOL_MEMORY_FLUSH',           // Cleanup operations
  'PROTOCOL_RESOURCE_SHUNT',         // Internal resource management
  'PROTOCOL_NEURO_LINK_HANDSHAKE',   // Background handshakes
];

// Actionable: Important events that should appear in NotificationCenter
export const ACTIONABLE_PROTOCOLS = [
  'PROTOCOL_THOUGHT_EMISSION',           // Silhouette ideas/thoughts (filtered by importance)
  'PROTOCOL_ARCHITECTURAL_RFC',          // Needs user approval
  'PROTOCOL_EPISTEMIC_GAP_DETECTED',     // New discovery/curiosity
  'PROTOCOL_COST_ANOMALY',               // Budget warning
  'PROTOCOL_DATA_CORRUPTION',            // Error alert
  'PROTOCOL_TRAINING_COMPLETE',          // Training finished
  'PROTOCOL_TASK_COMPLETION',            // Major task done
  'PROTOCOL_INCIDENT_REPORT',            // Research found issue
  'PROTOCOL_GENESIS_TRIGGER',            // Code injection approved
  'PROTOCOL_MISSING_CREDENTIAL',         // New: Credential Safety
  'PROTOCOL_MEMORY_QUARANTINE',          // Memory node quarantined (not deleted)
  'PROTOCOL_CONTRADICTION_DETECTED',     // Contradiction found in memory base
  'PROTOCOL_Z3_VERIFICATION_FAILED',     // Action blocked by formal logic verification
];


// --- KERNEL AGENTS (The Seed) ---
// These are the core cognitive functions that always exist.
export const KERNEL_HEROS: Agent[] = [
  {
    id: 'core-01',
    name: 'Orchestrator_Prime',
    teamId: 'TEAM_CORE',
    category: 'CORE',
    roleType: AgentRoleType.LEADER,
    role: 'System Controller',
    status: AgentStatus.WORKING,
    enabled: true,
    cpuUsage: 12, ramUsage: 150, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    capabilities: [AgentCapability.SYSTEM_DESIGN, AgentCapability.CONTEXT_MANAGEMENT, AgentCapability.TOOL_WEB_SEARCH, AgentCapability.TOOL_MEMORY_WRITE],
    tier: AgentTier.CORE,
    preferredMemory: 'VRAM'
  },
  {
    id: 'core-02',
    name: 'Intent_Analyzer_Alpha',
    teamId: 'TEAM_CORE',
    category: 'CORE',
    roleType: AgentRoleType.WORKER,
    role: 'Prompt Engineer Lead',
    status: AgentStatus.WORKING,
    enabled: true,
    cpuUsage: 15, ramUsage: 120, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    tier: AgentTier.CORE,
    preferredMemory: 'VRAM'
  },
  {
    id: 'core-03',
    name: 'Workflow_Architect',
    teamId: 'TEAM_CORE',
    category: 'CORE',
    roleType: AgentRoleType.WORKER,
    role: 'System Evolutionist',
    status: AgentStatus.IDLE,
    enabled: true,
    cpuUsage: 25, ramUsage: 200, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    tier: AgentTier.CORE,
    preferredMemory: 'VRAM'
  },
  {
    id: 'ctx-01',
    name: 'The_Librarian',
    teamId: 'TEAM_CONTEXT',
    category: 'DATA',
    roleType: AgentRoleType.LEADER,
    role: 'Context Keeper',
    status: AgentStatus.WORKING,
    enabled: true,
    cpuUsage: 8, ramUsage: 350, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    tier: AgentTier.SPECIALIST,
    preferredMemory: 'VRAM'
  }
];

// --- EXTENDED LIBRARY (The Swarm Blueprints) ---
// These are specialists that can be hydrated on-demand.
export const SPECIALIST_LIBRARY: Agent[] = [
  {
    id: 'strat-01',
    name: 'Strategos_X',
    teamId: 'TEAM_STRATEGY',
    category: 'OPS',
    roleType: AgentRoleType.LEADER,
    role: 'Strategic Planner',
    status: AgentStatus.IDLE,
    enabled: true,
    cpuUsage: 5, ramUsage: 200, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    capabilities: [AgentCapability.CAMPAIGN_STRATEGY, AgentCapability.TOOL_WEB_SEARCH],
    tier: AgentTier.SPECIALIST,
    preferredMemory: 'VRAM'
  },
  {
    id: 'dev-lead',
    name: 'Code_Architect',
    teamId: 'TEAM_DEV',
    category: 'DEV',
    roleType: AgentRoleType.LEADER,
    role: 'Lead Developer',
    status: AgentStatus.IDLE,
    enabled: true,
    cpuUsage: 0, ramUsage: 0, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    capabilities: [AgentCapability.CODE_GENERATION, AgentCapability.SYSTEM_DESIGN],
    tier: AgentTier.SPECIALIST,
    preferredMemory: 'VRAM'
  },
  {
    id: 'mkt-lead',
    name: 'Creative_Director',
    teamId: 'TEAM_MKT',
    category: 'MARKETING',
    roleType: AgentRoleType.LEADER,
    role: 'Brand Director',
    status: AgentStatus.IDLE,
    enabled: true,
    cpuUsage: 0, ramUsage: 0, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    capabilities: [AgentCapability.VISUAL_DESIGN, AgentCapability.CAMPAIGN_STRATEGY, AgentCapability.TOOL_IMAGE_GENERATION],
    tier: AgentTier.SPECIALIST,
    preferredMemory: 'VRAM'
  },
  {
    id: 'sci-03',
    name: 'Researcher_Pro',
    teamId: 'TEAM_SCIENCE',
    category: 'SCIENCE',
    roleType: AgentRoleType.WORKER,
    role: 'Senior Researcher',
    status: AgentStatus.IDLE,
    enabled: true,
    cpuUsage: 0, ramUsage: 160, lastActive: Date.now(),
    memoryLocation: 'VRAM',
    capabilities: [AgentCapability.RESEARCH, AgentCapability.TOOL_WEB_SEARCH, AgentCapability.TOOL_RFC_REQUEST],
    tier: AgentTier.SPECIALIST,
    preferredMemory: 'VRAM'
  }
];

// Export the Kernel as the initial agent set
export const INITIAL_AGENTS: Agent[] = [...KERNEL_HEROS];

export const QDRANT_CONFIG = {
  url: getEnvVar('QDRANT_URL', 'http://localhost:6433'), // matches docker-compose.yml published REST port
  collectionName: 'silhouette_memory_v1',
  embeddingSize: 384 // using all-MiniLM-L6-v2
};

export const DEFAULT_AUTONOMOUS_CONFIG: AutonomousConfig = {
  enabled: false,
  maxConcurrentAgents: 10,
  autoApprovalThreshold: 'routine',
  budgetCap: 100,
  allowedDomains: ['localhost', 'github.com', 'stackoverflow.com', 'npmjs.com']
};

export const DEFAULT_API_CONFIG = {
  enabled: true,
  apiKey: getEnvVar('VITE_SILHOUETTE_API_KEY', getEnvVar('VITE_API_KEY', '') as string),
  port: 3005
};

export const REPLICATE_CONFIG = {
  apiKey: getEnvVar('REPLICATE_API_TOKEN', ''),
  models: {
    primary: "stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b",
    fallback: "black-forest-labs/flux-dev" // Image fallback. Video generation routes through VeoService (google/veo-3.1).
  }
};

// Redis config: supports REDIS_URL (Docker prod) or individual host/port (dev)
// Dev docker-compose maps 6499:6379, prod uses standard 6379
const parseRedisUrl = (): { host: string; port: number; password?: string } => {
  const url = getEnvVar('REDIS_URL');
  if (url) {
    try {
      const parsed = new URL(url);
      return {
        host: parsed.hostname,
        port: parseInt(parsed.port) || 6379,
        password: parsed.password || undefined,
      };
    } catch {
      console.warn('[CONFIG] Invalid REDIS_URL, falling back to individual vars');
    }
  }
  return {
    host: getEnvVar('REDIS_HOST', 'localhost') as string,
    port: parseInt(getEnvVar('REDIS_PORT', '6499') as string),
    password: getEnvVar('REDIS_PASSWORD'),
  };
};

export const REDIS_CONFIG = parseRedisUrl();

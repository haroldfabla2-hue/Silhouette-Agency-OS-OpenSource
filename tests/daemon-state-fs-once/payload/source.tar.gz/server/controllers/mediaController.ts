import { isDemoModeEnabled } from '../../services/security/capabilityState';
import { Request, Response } from 'express';
import { mediaService } from '../../services/mediaService';
import { mediaManager } from '../../services/mediaManager';
import { videoFactory } from '../../services/media/videoFactory';
import { localVideoService } from '../../services/media/localVideoService';
import { resourceManager } from '../../services/resourceManager';
import { stockService } from '../../services/stockService';
import { campaignService } from '../../services/campaignService';

/**
 * MediaController - Handles all /v1/media/* endpoints
 * Central hub for visual asset generation, compositing, and queue management
 */
class MediaController {

    // ==================== VIDEO QUEUE ====================

    /**
 * POST /v1/media/queue
 * Queue a video generation job with full parameter control
 */
    async queueVideo(req: Request, res: Response) {
        try {
            const {
                prompt,
                image,
                engine = 'WAN',
                // Advanced parameters
                duration = 5,
                fps = 24,
                aspectRatio = '16:9',
                resolution = '1024x1024',
                // Camera control (Kling-inspired)
                camera,
                // Keyframes A→B
                keyframeStart,
                keyframeEnd,
                // Quality settings
                guidanceScale = 7.5,
                inferenceSteps = 30,
                motionStrength = 0.5,
                negativePrompt,
                seed,
                stylePreset
            } = req.body;

            if (!prompt) {
                return res.status(400).json({ success: false, error: 'Missing prompt' });
            }

            // Log full parameters for debugging
            console.log('[MediaController] 📥 Queue Video Request:', {
                prompt: prompt.substring(0, 50) + '...',
                engine,
                camera,
                hasKeyframes: !!(keyframeStart || keyframeEnd),
                duration,
                fps
            });

            // Pass all parameters to video factory
            // [R10] verification scripts identify their jobs with x-job-origin: test
            const origin = req.get('x-job-origin') === 'test' ? 'TEST' : 'USER';

            const result = await videoFactory.createVideo(prompt, duration, image, engine, {
                fps,
                aspectRatio,
                resolution,
                camera,
                keyframeStart,
                keyframeEnd,
                guidanceScale,
                inferenceSteps,
                motionStrength,
                negativePrompt,
                seed,
                stylePreset
            }, origin);

            if (result) {
                return res.json({
                    success: true,
                    message: {
                        id: result.url,
                        status: 'QUEUED',
                        prompt,
                        engine,
                        provider: result.provider,
                        // Echo back parameters for confirmation
                        params: {
                            duration,
                            fps,
                            camera,
                            hasKeyframes: !!(keyframeStart || keyframeEnd)
                        }
                    }
                });
            }

            return res.status(500).json({ success: false, error: 'Failed to queue video' });
        } catch (error: any) {
            console.error('[MediaController] Queue Error:', error);
            return res.status(500).json({ success: false, error: error.message });
        }
    }

    /**
     * DELETE /v1/media/queue/:id
     * [R10] test-cleanup only: refuses to remove anything that is not a
     * TEST-origin job, so production queue entries can never be deleted here.
     */
    public removeQueueJob = async (req: Request, res: Response) => {
        const result = localVideoService.removeTestJob(String(req.params.id || ''));
        if (result.removed) return res.json({ success: true });
        const status = result.reason === 'not_found' ? 404 : 403;
        return res.status(status).json({ success: false, error: result.reason });
    };

    /**
     * POST /v1/media/queue/quarantine
     * Quarantine legacy jobs with backup (never delete).
     * Body: { olderThan?: ISODateString, ids?: string[] } - at least one required.
     */
    public quarantineQueue = async (req: Request, res: Response) => {
        const { olderThan, ids } = req.body || {};
        if (!olderThan && (!Array.isArray(ids) || ids.length === 0)) {
            return res.status(400).json({ success: false, error: 'Provide olderThan (ISO date) and/or non-empty ids[]' });
        }
        if (olderThan && isNaN(new Date(olderThan).getTime())) {
            return res.status(400).json({ success: false, error: 'olderThan must be a valid ISO date' });
        }
        if (ids !== undefined && !Array.isArray(ids)) {
            return res.status(400).json({ success: false, error: 'ids must be an array of strings' });
        }
        const result = localVideoService.quarantineJobs({ olderThan, ids });
        return res.json({ success: true, ...result });
    };

    /**
     * GET /v1/media/queue
     * Get all queued video jobs
     */
    async getQueue(req: Request, res: Response) {
        try {
            const jobs = localVideoService.getQueueStatus();
            return res.json(jobs);
        } catch (error: any) {
            console.error('[MediaController] GetQueue Error:', error);
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * GET /v1/media/queue/:id
     * Get specific job status
     */
    async getJobStatus(req: Request, res: Response) {
        try {
            const { id } = req.params;
            const jobs = localVideoService.getQueueStatus();
            const job = jobs.find(j => j.id === id);

            if (job) {
                return res.json(job);
            }
            return res.status(404).json({ error: 'Job not found' });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    // ==================== IMAGE GENERATION ====================

    /**
     * POST /v1/media/generate/image
     * Generate an image from prompt with optional style
     */
    // [SECURITY] No grant is issued by this route: an authenticated request
    // is not proof of human intent. The generation gates at the provider
    // boundary; paid cloud generation is hard-blocked in this delivery
    // (pending an authorized budget/cap mechanism - CERO COBROS).
    async generateImage(req: Request, res: Response) {
        try {
            const { prompt, style } = req.body;
            if (!prompt) {
                return res.status(400).json({ error: 'Missing prompt' });
            }

            console.log(`[MediaController] 🎨 Generate image with style: ${style || 'default'}`);
            const url = await mediaService.generateImage(prompt, style);
            return res.json({ url });
        } catch (error: any) {
            console.error('[MediaController] GenerateImage Error:', error);
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * POST /v1/media/enhance
     * Enhance an existing image
     */
    async enhanceImage(req: Request, res: Response) {
        try {
            const { image, prompt, strength = 0.3 } = req.body;
            if (!image) {
                return res.status(400).json({ error: 'Missing image' });
            }

            const url = await mediaService.enhanceImage(image, prompt || 'enhance', strength);
            return res.json({ url });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    // ==================== CAMPAIGNS ====================

    /**
     * POST /v1/media/campaign/create
     * The MediaStudio "Director" flow: turns an objective + brand into a
     * CampaignBlueprint shotlist. Operator-initiated (global Bearer auth);
     * effects are an LLM shotlist (existing quota) plus stock-image scouting
     * - no wallet-bearing provider call. Shot production afterwards goes
     * through the normal media endpoints and their own gates.
     */
    async createCampaign(req: Request, res: Response) {
        try {
            const { objective, brandId } = req.body;
            if (!objective || !brandId) {
                return res.status(400).json({ error: 'Missing objective or brandId' });
            }

            console.log(`[MediaController] 🎬 Campaign planning: "${objective}" for brand ${brandId}`);
            const blueprint = await campaignService.createCampaign(objective, brandId);
            if (!blueprint) {
                // Only a missing Brand Twin is a 404.
                return res.status(404).json({ error: 'Brand Twin not found for the given brandId', code: 'BRAND_TWIN_NOT_FOUND' });
            }
            return res.json(blueprint);
        } catch (error: any) {
            // Typed, deployment-level unavailability: hard block on
            // potentially-paid external generation (CERO COBROS) or, once a
            // designed authorization mechanism exists, failed/misconfigured
            // shotlist generation. Messages are static and safe to show.
            if (error?.code === 'EXTERNAL_GENERATION_DENIED'
                || error?.code === 'SHOTLIST_UNAVAILABLE') {
                return res.status(503).json({ error: error.message, code: error.code });
            }
            // Unexpected: log internals, never leak them to the client.
            console.error('[MediaController] CreateCampaign Error:', error);
            return res.status(500).json({ error: 'Campaign planning failed' });
        }
    }

    // ==================== COMPOSITING ====================

    /**
     * POST /v1/media/composite
     * Real-Hybrid composite pipeline
     */
    async composite(req: Request, res: Response) {
        try {
            const { productImage, anchorImage, prompt } = req.body;
            if (!productImage || !prompt) {
                return res.status(400).json({ error: 'Missing productImage or prompt' });
            }

            const result = await mediaService.generateRealHybridComposite(productImage, anchorImage, prompt);
            return res.json(result);
        } catch (error: any) {
            console.error('[MediaController] Composite Error:', error);
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * POST /v1/media/critique
     * QA analysis using Gemini Vision
     */
    async critique(req: Request, res: Response) {
        try {
            const { image, brand, prompt } = req.body;
            if (!image) {
                return res.status(400).json({ error: 'Missing image' });
            }

            // Import geminiService dynamically to avoid circular deps
            const { geminiService } = await import('../../services/geminiService');

            const analysisPrompt = `
You are a brand compliance expert. Analyze this image against the brand guidelines.

Brand: ${brand?.name || 'Unknown'}
Original Prompt: ${prompt || 'N/A'}
Brand Rules: ${JSON.stringify(brand?.manifesto || {}, null, 2)}

Evaluate:
1. Color consistency with brand palette
2. Emotional tone match
3. Typography appropriateness
4. Overall brand alignment

Respond in JSON format:
{
  "score": 0-100,
  "pass": true/false (pass if score >= 70),
  "reasoning": "brief explanation",
  "feedback": "specific improvement suggestion"
}`;

            const response = await geminiService.generateText(analysisPrompt);

            // Parse JSON from response
            try {
                const jsonMatch = response.match(/\{[\s\S]*\}/);
                if (jsonMatch) {
                    const report = JSON.parse(jsonMatch[0]);
                    return res.json(report);
                }
            } catch {
                // Fallback if parsing fails
            }

            return res.json({
                score: 75,
                pass: true,
                reasoning: 'Auto-approved (analysis service unavailable)',
                feedback: 'Manual review recommended'
            });
        } catch (error: any) {
            console.error('[MediaController] Critique Error:', error);
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * POST /v1/media/upscale
     * Upscale image to 4K using Real-ESRGAN
     */
    async upscale(req: Request, res: Response) {
        try {
            const { image, scale = 4 } = req.body;
            if (!image) {
                return res.status(400).json({ error: 'Missing image' });
            }

            const url = await mediaService.upscaleImage(image, scale);
            return res.json({ url });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    // ==================== ASSET MANAGEMENT ====================

    /**
     * GET /v1/media/assets
     * List local visual assets
     */
    async listAssets(req: Request, res: Response) {
        try {
            const type = (req.query.type as string) || 'all';
            const limit = parseInt(req.query.limit as string) || 20;

            let assets: string[] = [];

            if (type === 'all' || type === 'image') {
                const images = await mediaManager.listAvailableAssets('image');
                assets = [...assets, ...images];
            }
            if (type === 'all' || type === 'video') {
                const videos = await mediaManager.listAvailableAssets('video');
                assets = [...assets, ...videos];
            }

            return res.json({
                assets: assets.slice(0, limit),
                count: assets.length,
                source: 'local_library'
            });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * GET /v1/media/search
     * Search stock photos (Unsplash)
     */
    async searchAssets(req: Request, res: Response) {
        try {
            const query = req.query.query as string;
            if (!query) {
                return res.status(400).json({ error: 'Missing query parameter' });
            }

            const results = await stockService.searchImages(query);
            return res.json(results);
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    // ==================== BRAND MANAGEMENT ====================

    /**
     * GET /v1/media/brand/:id
     * Load brand digital twin
     */
    async getBrand(req: Request, res: Response) {
        try {
            const { id } = req.params;

            // Import brand service dynamically
            const { lancedbService } = await import('../../services/lancedbService');

            // Search for brand in vector DB by content
            const results = await lancedbService.searchByContent(id, 1);

            if (results.length > 0) {
                // MemoryNode contains content, return the node data or parse content
                const node = results[0];
                try {
                    const brandData = JSON.parse(node.content);
                    return res.json(brandData);
                } catch {
                    return res.json({
                        id: node.id,
                        name: node.id,
                        content: node.content
                    });
                }
            }

            // Not found: only fabricate a placeholder brand in explicit demo mode.
            if (!isDemoModeEnabled()) {
                return res.status(404).json({ error: `Brand '${id}' not found in memory` });
            }
            return res.json({
                id: id,
                name: 'Demo Brand',
                manifesto: {
                    emotionalSpectrum: {
                        primary: 'Innovation',
                        secondary: ['Dynamic', 'Premium'],
                        forbidden: ['Cheap', 'Boring']
                    }
                }
            });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * GET /v1/media/brand/:id/rules
     * Get brand design rules for objective
     */
    async getBrandRules(_req: Request, res: Response) {
        try {
            // Generate rules based on brand and objective
            const rules = `Use bold, dynamic compositions. Emphasize innovation and premium quality. Avoid cluttered layouts.`;

            return res.json({ rules });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    // ==================== SYSTEM STATUS ====================

    /**
     * GET /v1/media/vram-status
     * Get current VRAM allocation status
     */
    async getVramStatus(req: Request, res: Response) {
        try {
            const owner = resourceManager.getCurrentOwner();
            const jobs = localVideoService.getQueueStatus();
            const queueLength = jobs.filter(j => j.status === 'QUEUED').length;
            const processingJob = jobs.find(j => j.status === 'PROCESSING');

            return res.json({
                currentOwner: owner,
                isVideoActive: owner === 'VIDEO',
                queueLength,
                processingJobId: processingJob?.id || null,
                status: owner === 'VIDEO' ? 'GPU Reserved for Video' :
                    owner === 'LLM' ? 'LLM Active' : 'Idle'
            });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }

    /**
     * GET /v1/media/engines
     * List available video engines with recommendations
     */
    async getEngines(req: Request, res: Response) {
        try {
            const hasSourceImage = req.query.hasImage === 'true';
            const hasSourceVideo = req.query.hasVideo === 'true';

            const engines = [
                {
                    id: 'WAN',
                    name: 'WAN 2.1',
                    description: 'Text-to-Video generation (Local)',
                    recommended: !hasSourceImage && !hasSourceVideo,
                    requiresInput: false,
                    premium: false
                },
                {
                    id: 'SVD',
                    name: 'Stable Video Diffusion',
                    description: 'Image-to-Video with cinematic motion',
                    recommended: hasSourceImage && !hasSourceVideo,
                    requiresInput: true,
                    inputType: 'image',
                    premium: false
                },
                {
                    id: 'ANIMATEDIFF',
                    name: 'AnimateDiff Lightning',
                    description: 'Fast image animation',
                    recommended: false,
                    requiresInput: true,
                    inputType: 'image',
                    premium: false
                },
                {
                    id: 'VID2VID',
                    name: 'Video-to-Video',
                    description: 'Transform existing video with style',
                    recommended: hasSourceVideo,
                    requiresInput: true,
                    inputType: 'video',
                    premium: false
                },
                {
                    id: 'VEO',
                    name: 'Veo 3.1 (Google)',
                    description: '4K + Native Audio (Cloud Premium)',
                    recommended: false,
                    requiresInput: false,
                    premium: true,
                    costPerSecond: 0.08
                }
            ];

            return res.json({
                engines,
                recommendation: engines.find(e => e.recommended)?.id || 'WAN'
            });
        } catch (error: any) {
            return res.status(500).json({ error: error.message });
        }
    }
}

export const mediaController = new MediaController();

# Integrated receiver source candidate, separate from published4054

Goal: one coherent next source candidate to validate after baseline-vs4054 static prerequisite, rather than more disconnected inventory. NO product/runtime application/publication or test acceptance yet.

Composition order:
1. Exact frozen4054 43file overlay copied into a NEW private proposal, published tests/static candidate remains byte-identical.
2.7fbb ingestion same-unsubscribe fixed producer slot and same actual resolveCuriosity child under original handler Operation.
3.afcad2 actual app webhook mount startup Promise retained at SAME source position and joined by root shutdown allSettled. No route reordering/exposure fix.
4.0cd6 actual IntegrationHub loadProviders constructor Promise retained in fixed initial slot and joined before storage, not future receiver certificate.
5.fb9db801 production AccountStore actual store+manager ownership, OAuth pre-acquisition callback close receipts and retained originals, separate primary/cleanup failure. Its runtimeStopBindings includes prior ingestion+Hub fields and wins the intentional overlap. No generic receiverOwner model installed; that model remains design only, not mistaken for product wiring.

Validation gates: full real tsconfig baseline+4054 first; then this independent integrated source compared against4054 under same compiler/dependency integrity, without changing published4054. Parser/source composition checks only here. No fake/mocked service or simulations. Existing static workflow controls and exact candidate may NOT be silently retargeted to this candidate. A future exact source packet/branch/digest and separate execution gate are needed for real tests, with actual backend/native prerequisites and original evidence/cleanup rules. Fixed scopes remain42; no capacity increase, runtime fit pending.

All global UNKNOWN/native frontier/Redis UNSUPPORTED/global marker stay. This candidate does NOT implement a complete HTTP/native/plugin owner layer, does NOT certify arbitrary dynamic plugin imports/timers or escaped references, and does not claim global quiescence. Concrete remaining receiver gap processEvent->routeEvent is detached with actual handler imports; generic WeakMap owner design is not applied here. HTTP response/transport.close still not a global join. Conservative failed physical receipts may prevent AccountStore close; primary error retained. Current body of persistProviders is empty async, so no imaginary persistence IO capture.

Composition evidence maps every overwrite and SHA. Published product baseline, static YAML/controller and4054 overlay are untouched. Real-runtime readiness remains gated on typecheck and review of this exact coherent candidate, not on parser pass.

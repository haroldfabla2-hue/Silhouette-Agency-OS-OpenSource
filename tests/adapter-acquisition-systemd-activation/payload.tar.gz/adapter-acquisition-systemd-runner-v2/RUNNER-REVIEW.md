# Adapter acquisition, complete INACTIVE systemd wiring

No execution, publication, workflow activation, merge or deploy. V2 appAdapter/transportOwnership/ownedBackendSession, eight case bodies and original RUNTIME-LOCK remain frozen. The only identity overlay is the previously reviewed verifier/profile; runtime metadata and explicit TAP reporter are orchestration additions, not new product behavior or test assertions.

## Contents and exact source boundaries

- adapter-acquisition-v2.FROZEN.tar.gz is the original reviewed55,239-byte archive, SHA2567de96b7e6e90bdc47ed22ae5b3306e78c142ff7c8873d60021c9e1788d8fec66.
- candidate contains its exact source/fixtures/fallbacks and original lock. verify-environment.cjs has the explicit systemd checker overlay from identity-v1, pinned by EXECUTION-PROFILE.json. runtime-metadata.cjs is new public-only orchestration, no product imports.
- compiler contains the identical two frozen TypeScript5.8.2 source-loader files. Full types are separately locked TS5.8.3/@types-node22.19.1, never this loader.
- prepare-adapter.INACTIVE.py verifies the review manifest, runs real full types first, then reuses exact existing public rootfs reconstruction. No fixture launch in preparation. No CLI main runs any script automatically.
- typecheck-adapter.INACTIVE.py uses exact Git archive cd0066be/tree400b13d1ca7406c98e42c8d8c4975a4456bc1fb2 plus original v2 candidate.patch, original full tsconfig graph, actual lockfile dependencies, no scripts/native/product evaluation, no stubs. It checks source/selected hashes, compiler version/bytes, node types, lock before/after and writes source-bound receipt. Install360s/types120s, logs capped1MiB per subprocess. Original public Git HTTPS mapping and clean HOME/npm configs retained.
- adapter-services.INACTIVE.py imports only the hash-pinned existing direct-services runner/context from exact baseline paths. It calls existing extract_reviewed, command, durable, unit_state, NOT the old Narrative run()/real_phase()/oracle. Its own one-batch oracle has no Narrative success path.
- ADAPTER-SYSTEMD-ROOTFS.json is exact5987 original targets plus24 additions, total6011. All old rows unchanged. New additions are frozen candidate bytes/profile, two compiler files and runtime metadata. Every destination/bytes/mode/hash and exact file set is checked before mounts. The prior identity-v1 manifest had23 additions; only new addition is public runtime-metadata.cjs.
- adapter-batch.service.INACTIVE retains reviewed systemd containment and adds only --require of the public metadata module and explicit --test-reporter=tap to the one invocation. Python bootstrap emits its own version/kernel metadata then execve clears all inherited credentials/config.

## Runtime identity and confinement

Choose the previously admitted hosted systemd route, not unadmitted local bwrap. Prior run44839877445 is historical evidence only; current authenticated hosted context/root custody/current event and manager are checked again. Exact original archive119565c089bfc576ee9a96c5c785dba4eebdcdce9117c63ea3d3a41c4ab52e39/base manifest/dependent reconstruction pins remain. Missing artifact fails preparation. No substitute artifact or automatic repin.

Identity profile fixes real Node/Python/libc rootfs hashes, linux/x64 ABI, original lock hash and exact verifier overlay. Development kernel/version-string equality is removed, not replaced by unchecked executables. Loader still checks all original candidate/fallback/compiler bytes. Host review manifest pins profile/overlay before readonly mount. No environment-selected profile. Seccomp checks ELF/audit arch in its one actual-negative child only; it is not general isolation.

RootDirectory is public reviewed rootfs, ProtectSystemstrict/ProtectHomeyes, UID/GID1000, no groups or capabilities, PrivateNetwork/PrivateDevices, NoNewPrivileges, inaccessible /proc/sys/run, protected kernel/modules/controlgroups. No host HOME/private DB/.git/credentials/checkout mounts. Only work/tmp writable: tmpfs32MiB4096inodes and16MiB2048inodes, noexec/nosuid/nodev, UID1000mode0700. Evidence under /work/evidence is outside child cwd under /tmp. The other /app content is dormant reviewed public source, never the execution target.

Service remains MemoryMax512MiB, swap0, tasks64, OOMPolicystop/MemoryOOMGroupyes, CPUQuota100%, period100ms, RuntimeMax45s/start5s/stop2s, KillModecontrol-group, Restartno. Readback CPUQuotaPerSecUSec1s is normalized PER SECOND, not quota per100ms period. With CPUQuotaPeriodUSec100ms the effective kernel quota is100ms per100ms. Service is unchanged. Runner exports wanted/actual and both unit interpretations; it does not incorrectly demand CPUQuotaPerSecUSec100ms (which would be10%). Grounding: https://github.com/systemd/systemd/issues/8853 and https://freedesktop.org/software/systemd/man/latest/systemd.resource-control.html .

## Exactly one runtime invocation

/usr/bin/node --max-old-space-size=192 --require /candidate/runtime-metadata.cjs --test --test-reporter=tap --test-concurrency=1 --test-timeout=30000 /candidate/tests/adapter-acquisition/contracts.node.cjs

Eight unchanged cases, no filtering/retry/duplicate child invocation. Runtime metadata emits only Node/platform/arch/kernel; Python bootstrap emits Python/kernel. No env dumps. ProviderOFF env reconstructed by execve; no token passes from authenticated context step into service. No provider/native addon/DB module is mounted for the new loader closure. No pre-product probe or old Narrative writer/reader executes.

## Oracle and termination model

Require natural terminal unit state: active/exited, Resultsuccess, ExecMainCode1/Status0, MainPID0, ControlPID0, ExitTypecgroup, all wanted properties including actual cgroup path and limits. Systemd ExitTypecgroup natural exited is the existing whole-cgroup-empty model; this is not a new /proc census or a claim from main PID alone. Timeout/OOM/external batch kill/failure makes batch unsuccessful, regardless of earlier TAP. No stop/kill before this assertion on success.

Require exact eight TAP names in order, plan1..8, tests8/pass8/fail0/suites0/cancelled0/skipped0/todo0, no not-ok. Unit exit0 with incomplete TAP never passes. Parse runtime metadata with fixed schema, bounded count, no raw environment.

Require exactly eight external case receipts and exact modes, no duplicates/extras: normal, bind-fail, late-boot, boot-error, ready-disconnect, ready-fault, actual-negative, normal-positive. All watchdog/overflow/reap-timeout flags false, reapedtrue, output<=65,536bytes and allShutdownValidatedfalse.

Natural receipts: normal/bind-fail/actual-negative code1, normal-positive code0, signalnull, no kill requests, cleanupForcedfalse/naturalExittrue. Expected forced negative receipts: late-boot/boot-error/ready-disconnect/ready-fault each cleanupForcedtrue, naturalExitfalse, code null/signalSIGKILL and exactly one accepted expected cleanup kill. Those are test-lab negative cleanup, not natural product exit or global shutdown. A watchdog/overflow kill already consumed cannot hide under cleanup; flags remain and fail.

Batch stdout/stderr log is bounded by tmpfs16MiB in runtime and collection1MiB; oversize is unsuccessful evidence outcome. Per-case log capped65,536 in child collector. Per-case reap1s; outer systemd wall45s plus bounded50s host wait. On unsuccessful batch host stops whole cgroup, records before/after; must confirm inactive/failed and no main/control PID before evidence/export/unmount. Cleanup unknown retains root and mounts until VM teardown, resultUNKNOWN. No automatic retry. Expected per-case forced cleanup does not imply outer forced cleanup; any forced outer cleanup invalidates batch success.

Final pass label is PASS_ADAPTER_BOUNDARY_EIGHT_CASES_ONLY. Never full application, no-debt, durability, provider behavior, selected caller safety, merge/deployment or allShutdownValidatedtrue.

## Inactive calling contract and evidence

After a separate final activation/source authorization, preparation calls prepare-adapter.prepare(repository, review_manifest_sha) in a fresh hosted job, with only public scoped preparation access. That function verifies all review package bytes and exact base tree, invokes one full types preparation, then existing330s reconstruction. Its scripts cannot be launched accidentally as CLI: main exitsINACTIVE.

After types, collect existing authenticated context snapshot with exact future current run/attempt1/job/repo/ref/head and root-seal the fixed handoff file, using the existing context source semantics. Do not reuse a prior snapshot. Existing source requires the existing branch/job identity; a future activation must preserve it or present an explicit separately reviewed context delta. No permissive widening is included.

Root then calls adapter-services.run with explicit repository, original archive/manifest paths, context source and expected_context, output receipt path, external review_manifest_sha and exact types_receipt_sha. Types receipt must identify this exact original candidate archive/base/lock/patch and successful real dependency install/full graph; prior receipt cannot satisfy source binding. All arguments belong to the future reviewed activation, not arbitrary incoming content.

Export fresh public-only receipt, selected caseJSON and bounded TAP only after stable terminal/confirmed stop. Include original/profile/rootfs/compiler/candidate hashes, actual versions/kernel, types lockbeforeafter/install/compiler exit+bounded logs, all case kill/natural flags, wanted/actual service states and cleanup state. No private source/environment/host logs. Keep public temporary root until VM teardown.

This package supplies complete inactive source wiring and exact manifests/service, not a live workflow. No source guard/ref/head transition is invented: final publication decision must provide exact future event commit and package SHA as with previous one-shot activations. No CI/push has occurred. Static parsing/hash/apply inspection is the only verification performed in preparing this package; no compiler, fixtures, filter, namespace or service was run.

## Final runner-v2 cleanup/source guards

Failure cleanup now captures ControlGroup of the exact owned unit BEFORE stop and requires cgroup.events populated0 before and after a bounded recursive scan of every descendant cgroup.procs. All must be empty; missing/disappeared cgroup, changed subtree, unreadable events or >128directories is unknown. No unmount/export-as-stable follows unknown. Success keeps the reviewed natural active/exited+ExitTypecgroup model unchanged. Types guard checks regular/non-symlink/16KiB bound BEFORE hashing/reading.

BASELINE-TRANSITIVE-PINS pins all1651 tracked baseline blobs, including every nested prepare-reviewed/assembler/emitter/control/manifest/compiler archive and source read by reconstruction. Source guard checks working bytes against Git blob identity before preparation and again before root runtime, rejects untracked files in transitive glob directories, and requires exact baseline tree. repository cwd must equal explicit repository and git-C HEAD must equal authenticated context. No passing source guard is inferred from a summary.

"""Read-only exact tracked public source guard. No product imports/execution."""
from pathlib import Path
import hashlib,json,subprocess,stat
HERE=Path(__file__).resolve().parent
def validate(repository):
    repository=Path(repository).resolve();doc=json.loads((HERE/'BASELINE-TRANSITIVE-PINS.json').read_text())
    actual=subprocess.check_output(['/usr/bin/git','rev-parse',doc['baseline']+'^{tree}'],cwd=repository,text=True).strip()
    if actual!=doc['tree']:raise RuntimeError('BASELINE_TREE_IDENTITY')
    for relative,wanted in doc['files'].items():
        p=repository/relative
        if not p.is_file() or p.is_symlink():raise RuntimeError('TRANSITIVE_SOURCE_TYPE')
        raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if blob!=wanted['gitBlobSha1']:raise RuntimeError('TRANSITIVE_SOURCE_BYTES')
    # Disallow untracked files in transitive source directories, whose glob
    # enumeration is part of the existing assembler's semantics.
    tracked=set(doc['files'])
    for prefix in ['tests/narrative-directed','tests/narrative-directed-activation','tests/narrative-direct-systemd','scripts/containment']:
        for path in (repository/prefix).rglob('*'):
            if path.is_file() and path.relative_to(repository).as_posix() not in tracked:raise RuntimeError('TRANSITIVE_UNTRACKED_SOURCE')
    return {'baseline':doc['baseline'],'tree':doc['tree'],'filesVerified':len(doc['files'])}
if __name__=='__main__':raise SystemExit('INACTIVE: use explicit validate')

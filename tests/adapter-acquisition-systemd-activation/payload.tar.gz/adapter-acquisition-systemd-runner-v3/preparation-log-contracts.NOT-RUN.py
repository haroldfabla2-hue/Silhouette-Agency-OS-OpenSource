"""Authored public preparation-only tests. NOT RUN, no product/native/provider.
Real child processes, no patching npm/DB/methods. Future execution review needed.
"""
from pathlib import Path
import importlib.util,json,sys,tempfile,unittest
HERE=Path(__file__).resolve().parent
class Scope(unittest.TestCase):
    def setUp(self):
        spec=importlib.util.spec_from_file_location('capture',HERE/'bounded-public-command.INACTIVE.py');self.capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.capture)
    def test_real_dependency_sized_file_not_limited_by_log_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            script="from pathlib import Path;Path('public-dependency.bin').write_bytes(b'x'*2097152);print('done')"
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c',script],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'public.log',timeout_seconds=5)
            self.assertTrue(result['successful']);self.assertEqual((root/'public-dependency.bin').stat().st_size,2097152);self.assertEqual((root/'public.log').read_text(),'done\n');self.assertEqual(result['killRequests'],[])
    def test_real_log_overflow_is_unsuccessful_and_bounded(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);script="import os;os.write(1,b'x'*2097152)"
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c',script],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'public.log',timeout_seconds=5)
            self.assertFalse(result['successful']);self.assertTrue(result['logOverflow']);self.assertLessEqual((root/'public.log').stat().st_size,1048576);self.assertTrue(result['reaped'])
    def test_real_deadline_and_nonzero_are_not_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c','import time;time.sleep(10)'],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'timeout.log',timeout_seconds=1)
            self.assertFalse(result['successful']);self.assertTrue(result['wallTimeout']);self.assertTrue(result['reaped'])
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c','raise SystemExit(7)'],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'nonzero.log',timeout_seconds=5)
            self.assertFalse(result['successful']);self.assertEqual(result['returnCode'],7)
    def test_leader_exit_eof_does_not_hide_same_group_descendant(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            script="import os,time;pid=os.fork();(os.close(1),os.close(2),time.sleep(20)) if pid==0 else os._exit(0)"
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c',script],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'descendant.log',timeout_seconds=2)
            self.assertFalse(result['successful']);self.assertEqual(result['primaryFailure']['code'],'GROUP_SURVIVED_LEADER');self.assertTrue(result['killRequests']);self.assertTrue(result['groupAbsent'] or result['descendantsUnknown'])
    def test_timeout_kills_group_even_if_leader_dies_and_pipe_closes(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            script="import os,time,signal;pid=os.fork();(signal.signal(signal.SIGTERM,signal.SIG_IGN),os.close(1),os.close(2),time.sleep(20)) if pid==0 else time.sleep(20)"
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c',script],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'term-descendant.log',timeout_seconds=1)
            self.assertFalse(result['successful']);self.assertTrue(result['wallTimeout']);self.assertTrue(any(k['signal']=='SIGKILL' for k in result['killRequests']));self.assertTrue(result['groupAbsent'] or result['descendantsUnknown'])
    def test_actual_log_open_failure_is_returned_without_spawn(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            result=self.capture.run_public_command([sys.executable,'-I','-B','-S','-c','raise SystemExit(0)'],cwd=root,env={'PATH':'/usr/bin:/bin'},log_path=root/'absent'/'log',timeout_seconds=1)
            self.assertFalse(result['successful']);self.assertIsNone(result['pgid']);self.assertEqual(result['primaryFailure']['code'],'CAPTURE_EXCEPTION')
if __name__=='__main__':raise SystemExit('NOT RUN: execution requires explicit review; use unittest only after approval')

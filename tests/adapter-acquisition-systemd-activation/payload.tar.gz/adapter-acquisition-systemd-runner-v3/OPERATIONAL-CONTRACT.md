# Superseded identity-v1 draft

Use RUNNER-REVIEW.md and actual inactive source in this package. The old identity-only contract is retained in archive8b58fe80bd0c0e837c9464277f1f1fab11235a313508718aaeacc6ef1c9318bc, not an execution instruction. This package adds runtime metadata and complete batch/types wiring. No execution authority.

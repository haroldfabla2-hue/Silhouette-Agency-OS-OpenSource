"""INACTIVE preparation only, no product/native/provider/fixture evaluation.
Existing public reconstruction and actual locked full-types preparation reused.
Explicit call after source review; no command-line execution entry.
"""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,os,shutil
HERE=Path(__file__).resolve().parent
def need(ok,code):
    if not ok:raise RuntimeError(code)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare(repository,review_manifest_sha):
    # Verify all package bytes before importing even the preparation helper.
    need(sha(HERE/'SHA256.json')==review_manifest_sha,'PREPARATION_MANIFEST_PIN')
    rows=json.loads((HERE/'SHA256.json').read_text())
    for relative,wanted in rows.items():
        p=HERE/relative;need(p.is_file() and not p.is_symlink() and sha(p)==wanted,'PREPARATION_PAYLOAD_PIN')
    repository=Path(repository).resolve()
    need(subprocess.check_output(['/usr/bin/git','rev-parse','cd0066be67748f5948515bf3d20e6edc36d7b7c0^{tree}'],cwd=repository,text=True).strip()=='400b13d1ca7406c98e42c8d8c4975a4456bc1fb2','BASELINE_TREE_PIN')
    guard=HERE/'source-guard.INACTIVE.py';spec=importlib.util.spec_from_file_location('transitive_source_guard',guard);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.validate(repository)
    source=HERE/'typecheck-adapter.INACTIVE.py';spec=importlib.util.spec_from_file_location('adapter_real_types',source);types=importlib.util.module_from_spec(spec);spec.loader.exec_module(types)
    # Its ROOT was import-time cwd, force exact public repository explicitly.
    types.ROOT=repository;types.main()
    pins=json.loads((HERE/'REUSE-PINS.json').read_text())
    helper=repository/'tests/narrative-direct-systemd/prepare-concurrency.INACTIVE.py'
    need(sha(helper)==pins['tests/narrative-direct-systemd/prepare-concurrency.INACTIVE.py'],'EXISTING_PREPARATION_PIN')
    # Public reconstruction only. Preserve original artifact/download/emission
    # failclosed pins and timeout; no fixture or old Narrative entry launched.
    selected_node=shutil.which('node')
    need(selected_node is not None and Path(selected_node).is_absolute(),'PREPARATION_NODE_NOT_ABSOLUTE_OR_MISSING')
    node=Path(selected_node).resolve()
    need(node.is_file() and os.access(node,os.X_OK),'PREPARATION_NODE_NOT_EXECUTABLE')
    # Keep only the selected setup-node directory and required system tools.
    # Both unchanged historical helper resolutions must select this binary.
    env={'PATH':str(node.parent)+':/usr/bin:/bin','HOME':'/tmp','LC_ALL':'C'}
    need(shutil.which('node',path=env['PATH'])==str(node),'PREPARATION_NODE_RESOLUTION_MISMATCH')
    # Existing preparation reads GH_TOKEN for scoped artifact fetch in its own
    # source-defined preparation subprocess only. Never pass it to root/runtime.
    if 'GH_TOKEN' in os.environ:env['GH_TOKEN']=os.environ['GH_TOKEN']
    done=subprocess.run(['/usr/bin/python3','-I','-B','-S',str(helper)],cwd=repository,env=env,timeout=330,check=False)
    need(done.returncode==0,'EXISTING_PUBLIC_RECONSTRUCTION_FAILED')
    return {'kind':'ADAPTER_PREPARATION_ONLY','productExecuted':False,'fixturesExecuted':False,'typesReceipt':'/tmp/adapter-real-typecheck/receipt.json','archive':'/tmp/narrative-directed-preparation/assembled/directed-image.docker.tar','manifest':'/tmp/narrative-directed-preparation/assembled/DIRECTED-ROOTFS.json'}
if __name__=='__main__':raise SystemExit('INACTIVE: no execution authority')

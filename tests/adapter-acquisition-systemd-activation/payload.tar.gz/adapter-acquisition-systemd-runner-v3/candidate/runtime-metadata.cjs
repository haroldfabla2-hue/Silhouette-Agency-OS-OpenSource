console.log('ADAPTER_RUNTIME_META '+JSON.stringify({kind:'NODE',node:process.version,platform:process.platform,arch:process.arch,kernel:require('node:os').release()}));

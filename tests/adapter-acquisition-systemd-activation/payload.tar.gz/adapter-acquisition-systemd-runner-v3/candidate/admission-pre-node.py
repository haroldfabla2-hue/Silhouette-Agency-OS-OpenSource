"""INACTIVE reviewed wrapper source, intended /candidate/admission-pre-node.py.
Only pre-Node admission, no post-Node keeper; exec exactly once, no product import.
"""
import os,time,json,sys
from pathlib import Path
root=Path('/work');ready=root/'admission-ready.json';permit=root/'admission-permit';nonce=os.urandom(32).hex()
# No shell, no network, no secrets inherited into Node. Public proof nonce only.
pending=root/'admission-ready.pending'
fd=os.open(pending,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'w') as stream:
    json.dump({'pid':os.getpid(),'nonce':nonce,'stage':'BEFORE_NODE'},stream);stream.flush();os.fsync(stream.fileno())
os.rename(pending,ready)
until=time.monotonic()+10
while True:
    if time.monotonic()>=until:raise SystemExit('ADMISSION_DEADLINE_NO_NODE')
    try:fd=os.open(permit,os.O_RDONLY|os.O_NOFOLLOW)
    except FileNotFoundError:
        if time.monotonic()>=until:raise SystemExit('ADMISSION_DEADLINE_NO_NODE')
        time.sleep(.02);continue
    with os.fdopen(fd,'rb') as stream:raw=stream.read(66)
    if time.monotonic()>=until:raise SystemExit('ADMISSION_DEADLINE_NO_NODE')
    if raw!=nonce.encode():raise SystemExit('ADMISSION_MISMATCH_NO_NODE')
    break
print('ADAPTER_PYTHON_META '+json.dumps({'python':sys.version.split()[0],'kernel':os.uname().release}),flush=True)
if time.monotonic()>=until:raise SystemExit('ADMISSION_DEADLINE_NO_NODE')
os.execve('/usr/bin/node',['/usr/bin/node','--max-old-space-size=192','--require','/candidate/runtime-metadata.cjs','--test','--test-reporter=tap','--test-concurrency=1','--test-timeout=30000','/candidate/tests/adapter-acquisition/contracts.node.cjs'],{'PATH':'/usr/bin:/bin','LC_ALL':'C','HOME':'/work','TMPDIR':'/tmp','NODE_ENV':'test','SILHOUETTE_PROVIDERS':'off','SILHOUETTE_BOOT_MODE':'normal','ACQ_REPO_ROOT':'/compiler','ACQ_PYTHON_PATH':'/usr/bin/python3','ACQ_EVIDENCE_ROOT':'/work/evidence'})

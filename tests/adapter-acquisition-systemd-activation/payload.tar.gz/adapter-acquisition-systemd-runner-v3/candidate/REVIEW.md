# Opt-in adapter acquisition v2, local source package

Baseline cd0066be67748f5948515bf3d20e6edc36d7b7c0, identical integrated tree85985cdb. Source/type/fixture files plus patch/manifest. No product/test execution, publication or integration. server/index.ts/currentBackendDrain/electron.cjs/CLI/channel/terminal remain byte-identical. No blocked-v1 prototype integration, Janitor change, hydration delta, global gate, provider or recovery feature.

## Guarantee A, transport acquired or proved not acquired

Actual appAdapter uses new transportOwnership helper for its real OwnedTransport instance. The helper installs permanent error/listening/connection handlers before listen. It retains exact actual sockets, marks productInvoked before calling real import factory, and retains its actual boot promise. Loopback/port0 production route unchanged. The listener is acquired while admission is closed, BEFORE product imports.

On bind failure the actual close callback must complete. Only closed/unlistening, never-ever-listened, zero sockets, product-never-invoked and bind-failed/settled can produce not-acquired. ERR_SERVER_NOT_RUNNING is accepted only for that measured never-acquired conjunction, not a shortcut for arbitrary caught errors. Caller validates strict primitive snapshot schema, including retention consistency. Unknown/error output remains unknown, no inference from adapterInvoked or catch text. No timer to keep a no-acquisition child stuck.

The production adapter still binds port0 only, no production port injection. Boundary occupied-port test uses the actual owner. A second authored negative fixture calls the complete real prepareActualAppAdapter + ownDesktopBackend route, via source-only allowlisted transpilation loader and a disposable Linux child with kernel seccomp bind denied (EPERM). No method replacement, product factory/DB stub, environment/cwd change inside adapter, or alternate production bind setting. The fixture creates explicit preexisting unopened non-SQLite anchor only for actual existing-root validation; no DB code should be imported. Loader refuses any product import as a test failure, not fake success. Failure to install filter/unsupported architecture fails rather than skips. This actual route fixture is authored but NOT RUN, so deterministic negative behavior remains unverified until approved execution.

## Guarantee B, acquired ownership retained honestly

Permanent transport error handler remains throughout imports and ready state. It closes admission (not socket/process) and latches fault. Before declaring ready adapter requires no fault and listeningtrue. A transport error can remove a listener; snapshot then reports retained sockets or retentionunverified, not a promise of survival. The helper never catches an import failure as no-acquisition.

Partial acquired boot failure returns its actual server and ownership inspection closure, authenticationReadyfalse and blocked drain. It does not closeAllConnections or close listener in catch. Actual boot/import task is retained/observed; failure does not erase acquired object. Session never reports ready for it. Existing fatal handlers for uncaught/unhandled errors are not rewritten; that separate corruption/fatal policy can still exit and is outside this graceful acquisition guarantee.

Before awaiting bind/imports, actual adapter shares its live ownership inspector through a trusted session-only callback, never IPC. Session can report actual listening/bootPending during late boot, not wait for a backend object.

Session stops no longer force exit at shutdown deadline or after drain rejection. Deadline only emits fixed bounded blocked status; operation remains retained. Acquired object is not closed; blocked is not desktop-stopped. Late boot result is still observed and updates backend ownership/status, then stop/drain called once. Repeated signals/owner stop join one task. If no actual listener/socket remains and IPC is lost, status is retentionUnverified; no artificial handle, survival promise or private recovery endpoint.

## Guarantee C, no mistaken release from IPC/signal

Session's genuine pre-adapter handshake failure can terminate naturally with failure status after clearing owned timers/disconnecting IPC. A bind result may do the same only with strict real no-acquisition proof. After invocation with unknown outcome, failure blocks rather than blindly closes/exits.

Blocked IPC send is best effort; disconnected send is not delivery. IPC loss latches ownerLost BEFORE joining any existing stop. From READY it fences roots then blocks before drain, preserving acquired resources even if that authored drain would fulfill. IPC loss during an already-authorized drain blocks transport release afterwards. Faulted/unknown live ownership is checked before drain and again immediately before normal transport release; a post-READY transport error cannot yield clean stopped. process.on signals remain installed after the first, avoiding default second-signal termination from once handlers. Source-owned stop/boot work shared, no replay/provider flush. allShutdownValidatedfalse/debtunknown explicit in status.

This opt-in source has no selected parent in current Electron/CLI. It is NOT a complete graceful close implementation. Its current real app adapter still has global unknown-writer barrier and throws before all stores closed; source session does not claim a full app certificate from void/fulfilled drain. The ordinary already-ready fulfilled-drain path retains its original actual transport close callback and natural termination, labelled adapter-transport-only/allShutdownValidatedfalse. It is NOT replaced by unconditional blocked. Stop-during-boot, rejection, failure, lost IPC, faulted/unverified transport and exceeded diagnostic deadline cannot use this normal path. A separate positive boundary fixture covers that compatibility, not full app no-debt closure. No normal selected path is degraded, and existing opt-in tests that expect forced exit are not silently repurposed. New separate fixture tests specify the revised bounded acquisition contract. Compatibility migration of old opt-in tests is pending if this source is ever selected/published.

## Fixtures provided, NOT RUN

contracts.node.cjs forks actual ownDesktopBackend, createTransportOwnership and real HTTP servers/error callbacks. Factory instrumentation is AUTHORED BOUNDARY TEST ONLY, not Silhouette appboot/auth/DB or a full closure certificate. It does not replace product methods or provide fake closed receipts.

- no handshake, factory never called, natural no-acquisition failure exit;
- occupied loopback port, actual EADDRINUSE and close callback, no boot factory call, strict not-acquired output, no ready/stopped, natural failure exit;
- actual acquired listener, finite factory held by test message, deadline -> blocked, real HTTP503 remains, repeated SIGINT/SIGTERM, release real delayed factory, ownership reflects late settlement and single stop/drain;
- actual listener plus authored boot exception retains socket capability; disconnect IPC does not terminate or close listener;
- READY with a would-fulfill drain, then IPC disconnect: roots fenced, drain NOT invoked, no stopped/close, real HTTP still responds;
- post-READY actual close/rebind to occupied loopback port produces real EADDRINUSE, not synthetic emit(error); source snapshot faulted/retentionUnverified blocks drain/clean close. Original listener is already lost by fixture, so no survival guarantee is claimed. The occupied fixture listener is merely the real conflict source, not reported as owned backend retention.
- ordinary READY successful fulfilled boundary drain observes actual server close callback and natural exit0, adapter-transport-only/allShutdownValidatedfalse.

Negative blocked test processes must be forcibly cleaned by laboratory parent. The test retains an external per-case evidence receipt under required ACQ_EVIDENCE_ROOT with watchdogFired/overflowFired/cleanupForced/reaped/exit/killRequests and naturalExit classification. Unexpected watchdog or overflow is always test failure even if its SIGKILL has already been reaped. Parent cleanup and reap wait are bounded. Child cwd deletion does not delete that receipt. The test records forced cleanup explicitly, only asserts bounded negative-contract behavior, and never calls it natural-exit/full-shutdown PASS. The fixtures have not been run. Natural exits tested are genuine no-acquisition exit1 and the ordinary already-READY authored boundary drain exit0. Neither is full app no-debt shutdown.

## Static verification only

Parse changed TS/JS and native --check JS/fixture files; apply-check against exact baseline; SHA256 per-file manifest and selected-file preservation hashes. No full dependency types, test execution, native import, namespace, provider or CI. No emitted module/rootfs/artifact identity is claimed. Actual selected-root negative fixture is provided but unexecuted; end-to-end product-owned late acquisition remains beyond these boundary factories.

## Limits

No durable transfer/recovery, no safe restart/quit claim, no exclusivity against second data owners, no protection from OS/external kills. Once a real listener disappears, ordinary EventEmitter listeners alone do not retain a process; report retentionUnverified. No fake keepalive. Bound app may still own hidden writers, same global barrier remains. Work inventory and source evidence continue in separate INVENTORY.md, not treated as satisfied by acquisition tests.

## Execution identity contract, still NOT authorization to run

RUNTIME-LOCK.json pins individual exact baseline fallback bytes, all candidate source/fixture bytes, TypeScript compiler+package bytes, Node binary/version/platform/arch/kernel release, Python binary/version. verify-environment runs before a child and inside source loader before compiler import; every source load checks its own expected candidate/fallback hash. Fallback closure is packaged under tests/adapter-acquisition/baseline, copied from exact Git objects and individually pinned, not the stale working tree. ACQ_REPO_ROOT supplies only the hash-pinned compiler location and cannot supply different source under the baseline label. Static pinning caught the working tree producerReceipts.ts mismatch; it is not used. ACQ_PYTHON_PATH must hash-match. Candidate.patch and lock identity are recorded in SHA256.json/package archive hash, avoiding a self-referential patch hash. No product evaluation occurred while gathering binary/version metadata.

seccomp checks actual Node ELF class/endian/e_machine against host machine, plus audit architecture in kernel filter. Only reviewed Linux x64 or arm64 ABI mapping is supported; the pinned current environment narrows that further. Filter denies bind EPERM only, not a universal sandbox/network/provider policy. No alternate architecture/toolchain is approved by this package. A changed environment requires regenerated identity file and separate review, not auto-repin at test runtime. Future execution must additionally honor the already-required disposable no-provider containment; this recipe alone is not an execution/target approval.

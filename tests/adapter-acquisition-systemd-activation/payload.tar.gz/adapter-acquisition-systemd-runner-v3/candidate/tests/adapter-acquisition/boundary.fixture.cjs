/* Authored boundary factory, not Silhouette appboot or DB. Real session class,
 * actual owner/server/listen/error callbacks. No replaced product methods. */
const http=require('node:http'),fs=require('node:fs');
(async()=>{
 const {ownDesktopBackend}=await import('../../server/desktop/ownedBackendSession.js');
 const {createTransportOwnership}=await import('../../server/desktop/transportOwnership.js');
 const mode=process.argv[2];let factoryCalls=0,bootCalls=0,stopCalls=0,drainCalls=0,control;
 const record=()=>fs.writeFileSync('boundary-observation.json',JSON.stringify({factoryCalls,bootCalls,stopCalls,drainCalls,status:control?.status()}));
 const openBackend=async({onOwnership})=>{
  factoryCalls++;
  const server=http.createServer((req,res)=>{res.writeHead(503);res.end()});
  const owner=createTransportOwnership(server,()=>{record();process.send?.({type:'boundary-fault',ownership:owner.snapshot()})});
  onOwnership(owner.snapshot);
  process.on('message',async message=>{
   if(message?.type!=='boundary-fault-ready')return;
   // Real loss/rebind failure, not server.emit(error) or method replacement.
   const occupied=http.createServer();await new Promise(ok=>occupied.listen(0,'127.0.0.1',ok));
   await new Promise(ok=>server.close(ok));server.listen(occupied.address().port,'127.0.0.1');
  });
  let blocker;
  if(mode==='bind-fail'){
   blocker=http.createServer();await new Promise(ok=>blocker.listen(0,'127.0.0.1',ok));
  }
  const bound=await owner.bind('127.0.0.1',blocker?blocker.address().port:0);
  if(blocker)await new Promise(ok=>blocker.close(ok));
  if(bound.kind!=='acquired'){
   fs.writeFileSync('negative-acquisition.json',JSON.stringify({bound,bootCalls}));
   return {acquisition:owner.noAcquisitionConfirmed()?'not-acquired':'unknown',ownership:owner.snapshot,authenticationReady:false};
  }
  process.send?.({type:'boundary-listener',port:server.address().port});
  try{
   return await owner.boot(async()=>{
    bootCalls++;record();
    if(mode==='late-boot')await new Promise(resolve=>process.on('message',message=>{if(message?.type==='boundary-release')resolve()}));
    if(mode==='boot-error')throw new Error('authored boundary failure, not app failure');
    return {acquisition:'acquired',ownership:owner.snapshot,server,authenticationReady:true,
     stopAdmission:async()=>{stopCalls++;record()},
     drain:async()=>{drainCalls++;record();if(!['normal-positive','ready-disconnect','ready-fault'].includes(mode))throw new Error('boundary retained acquisition')}};
   });
  }catch{
   return {acquisition:'acquired',ownership:owner.snapshot,server,authenticationReady:false,
    stopAdmission:async()=>{stopCalls++;record()},drain:async()=>{drainCalls++;record();throw new Error('boundary boot failed retained')}};
  }
 };
 control=await ownDesktopBackend({openBackend,handshakeMs:150,bootMs:100,shutdownMs:120,sendMs:30});
 process.on('message',message=>{if(message?.type==='boundary-observe'){record();process.send?.({type:'boundary-observation',...JSON.parse(fs.readFileSync('boundary-observation.json'))})}});
 process.send({type:'boundary-start'});
})();

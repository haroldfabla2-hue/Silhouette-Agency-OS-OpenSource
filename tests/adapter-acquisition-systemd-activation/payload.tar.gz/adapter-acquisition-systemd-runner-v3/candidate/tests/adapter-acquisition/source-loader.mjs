// Test-only source loader, never substitutes a module/function. Transpiles the
// exact allowlisted lifecycle closure; any product import fails the fixture.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const lock=require('./verify-environment.cjs').verify();
const ts=require(path.join(process.env.ACQ_REPO_ROOT,'node_modules/typescript/lib/typescript.js'));
const crypto=require('node:crypto');
const candidate=process.env.ACQ_CANDIDATE_ROOT,fallback=path.join(candidate,'tests/adapter-acquisition/baseline');
const allowed=new Set(['server/desktop/appAdapter.ts','server/desktop/transportOwnership.js','server/desktop/ownedBackendSession.js','server/desktop/startedResources.js','server/desktop/producerScope.js','server/desktop/workSession.js','server/desktop/existingRoot.js','server/desktop/privateSession.ts','services/lifecycle/desktopWork.js','services/lifecycle/desktopRefusal.js','services/lifecycle/producerReceipts.ts','services/lifecycle/ownedProducers.ts']);
export async function resolve(specifier,context,next){
 if(specifier.startsWith('node:'))return next(specifier,context);
 if(context.parentURL?.startsWith('file:')){
  const parent=fileURLToPath(context.parentURL);
  if(parent.startsWith(candidate+'/server/')||parent.startsWith(candidate+'/services/')){
   const base=path.resolve(path.dirname(parent),specifier);let relative=path.relative(candidate,base);
   if(!allowed.has(relative)&&allowed.has(relative+'.ts'))relative+='.ts';
   if(!allowed.has(relative))throw Error('PRODUCT_IMPORT_ATTEMPTED_BEFORE_NEGATIVE_BIND: '+relative);
   return {url:pathToFileURL(path.join(candidate,relative)).href,shortCircuit:true};
  }
 }
 return next(specifier,context);
}
export async function load(url,context,next){
 if(url.startsWith('file:')){
  const file=fileURLToPath(url),relative=path.relative(candidate,file);
  if(allowed.has(relative)){
   const local=fs.existsSync(file),bytes=fs.readFileSync(local?file:path.join(fallback,relative));
   const expected=(local?lock.candidate:lock.fallback)[relative];
   if(!expected||crypto.createHash('sha256').update(bytes).digest('hex')!==expected)throw Error('SOURCE_IDENTITY_MISMATCH '+relative);
   const source=bytes.toString('utf8');
   const emitted=ts.transpileModule(source,{fileName:relative,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022,allowJs:true}}).outputText;
   return {source:emitted,format:'module',shortCircuit:true};
  }
 }
 return next(url,context);
}

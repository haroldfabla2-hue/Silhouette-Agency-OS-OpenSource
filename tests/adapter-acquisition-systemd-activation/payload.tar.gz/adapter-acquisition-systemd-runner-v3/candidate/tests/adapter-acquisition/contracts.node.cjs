/* SOURCE ONLY, NOT RUN. Boundary factories are not appboot. Negative cleanup
 * is forced and logged externally, never natural-exit/full-shutdown success. */
const {test}=require('node:test'),assert=require('node:assert/strict'),{fork,spawn}=require('node:child_process');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const entry=path.join(__dirname,'boundary.fixture.cjs');
const sleep=ms=>new Promise(ok=>setTimeout(ok,ms));
function request(port){return new Promise((ok,fail)=>http.get({host:'127.0.0.1',port},res=>{res.resume();res.on('end',()=>ok(res.statusCode))}).on('error',fail))}
async function bounded(promise,ms){let timer;try{return await Promise.race([promise,new Promise((_,fail)=>{timer=setTimeout(()=>fail(Error('LAB_REAP_TIMEOUT')),ms)})])}finally{clearTimeout(timer)}}
async function run(mode,fn,{actual=false}={}){
 require('./verify-environment.cjs').verify();
 const evidenceRoot=process.env.ACQ_EVIDENCE_ROOT;assert.ok(evidenceRoot&&path.isAbsolute(evidenceRoot),'absolute ACQ_EVIDENCE_ROOT required');fs.mkdirSync(evidenceRoot,{recursive:true});
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'adapter-boundary-'));const candidate=path.resolve(__dirname,'../..');
 const c=actual?spawn(process.env.ACQ_PYTHON_PATH,[path.join(__dirname,'deny-bind.py'),process.execPath,'--experimental-loader',path.join(__dirname,'source-loader.mjs'),path.join(__dirname,'actual-negative.fixture.cjs')],{cwd:dir,env:{...process.env,ACQ_CANDIDATE_ROOT:candidate},stdio:['ignore','pipe','pipe','ipc']}):fork(entry,[mode],{cwd:dir,silent:true});
 const lab={mode,pid:c.pid,watchdogFired:false,overflowFired:false,cleanupForced:false,reapTimedOut:false,killRequests:[],exit:null,allShutdownValidated:false};
 let exited=false;const messages=[];let bytes=0,log='';
 const kill=cause=>{lab.killRequests.push({cause,at:new Date().toISOString(),requested:true,accepted:c.kill('SIGKILL')})};
 c.on('message',m=>messages.push(m));
 for(const stream of [c.stdout,c.stderr])stream.on('data',b=>{bytes+=b.length;if(log.length<65536)log+=b;if(bytes>65536&&!lab.overflowFired){lab.overflowFired=true;kill('overflow')}});
 const watchdog=setTimeout(()=>{lab.watchdogFired=true;kill('watchdog')},3000);
 const ended=new Promise(ok=>{
  c.once('error',()=>{lab.spawnError=true;clearTimeout(watchdog);ok({code:null,signal:null,spawnError:true})});
  c.once('exit',(code,signal)=>{exited=true;clearTimeout(watchdog);lab.exit={code,signal,at:new Date().toISOString()};ok({code,signal})});
 });
 const message=async type=>{const until=Date.now()+1800;while(Date.now()<until){const at=messages.findIndex(m=>m.type===type);if(at>=0)return messages.splice(at,1)[0];if(exited)throw Error('exit before '+type);await sleep(5)}throw Error('message deadline '+type)};
 const credentials={sessionId:crypto.randomBytes(32).toString('hex'),apiToken:crypto.randomBytes(32).toString('hex'),controlToken:crypto.randomBytes(32).toString('hex')};
 try{await message('boundary-start');await fn({c,dir,ended,message,messages,credentials,alive:()=>!exited});}
 finally{
  if(!exited&&!lab.spawnError){lab.cleanupForced=true;kill('expected-negative-or-failed-test-cleanup')}
  try{await bounded(ended,1000)}catch{lab.reapTimedOut=true}
  clearTimeout(watchdog);lab.outputBytes=bytes;lab.outputSha256=crypto.createHash('sha256').update(log).digest('hex');
  lab.reaped=exited;lab.naturalExit=exited&&lab.killRequests.length===0&&lab.exit.signal===null;
  // Retained outside deleted child cwd. Flags describe every kill request,
  // including a watchdog/overflow kill that exited before finally runs.
  const receipt=path.join(evidenceRoot,mode+'-'+process.pid+'-'+crypto.randomUUID()+'.json');fs.writeFileSync(receipt,JSON.stringify(lab,null,2));
  if(exited)fs.rmSync(dir,{recursive:true,force:true});
  assert.equal(lab.watchdogFired,false,'unexpected watchdog, see '+receipt);assert.equal(lab.overflowFired,false,'unexpected output overflow, see '+receipt);
  assert.equal(lab.reapTimedOut,false,'unreaped child, see '+receipt);assert.equal(lab.spawnError,undefined,'spawn failed, see '+receipt);
  assert.ok(!log.includes(credentials.apiToken)&&!log.includes(credentials.controlToken));
 }
}
test('never invoked adapter permits natural handshake failure exit',()=>run('normal',async x=>{
 assert.deepEqual(await x.ended,{code:1,signal:null});assert.ok(!fs.existsSync(path.join(x.dir,'negative-acquisition.json')));
}));
test('actual owner bind conflict proves no product invocation and exits naturally',()=>run('bind-fail',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});const proof=await x.message('desktop-not-acquired');assert.equal(proof.state,'not-acquired');
 const raw=JSON.parse(fs.readFileSync(path.join(x.dir,'negative-acquisition.json')));assert.equal(raw.bootCalls,0);assert.equal(raw.bound.kind,'not-acquired');
 assert.equal(raw.bound.ownership.releaseConfirmed,true);assert.equal(raw.bound.ownership.listening,false);assert.equal(raw.bound.ownership.sockets,0);assert.equal(raw.bound.ownership.productInvoked,false);
 assert.deepEqual(await x.ended,{code:1,signal:null});assert.ok(!x.messages.some(m=>['desktop-ready','desktop-stopped'].includes(m.type)));
}));
test('acquired listener survives stop deadline, late boot updates and repeated signals join',()=>run('late-boot',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});const listener=await x.message('boundary-listener');assert.equal(await request(listener.port),503);
 x.c.send({type:'desktop-shutdown',sessionId:x.credentials.sessionId,controlToken:x.credentials.controlToken});
 const first=await x.message('desktop-shutdown-blocked');assert.equal(first.state,'blocked');assert.equal(first.operationSettled,false);assert.equal(first.ownership.listening,true);assert.equal(first.ownership.bootPending,true);assert.equal(first.retentionUnverified,false);
 x.c.kill('SIGINT');x.c.kill('SIGTERM');assert.equal(x.alive(),true);assert.equal(await request(listener.port),503);
 x.c.send({type:'boundary-release'});await sleep(50);x.c.send({type:'boundary-observe'});const observation=await x.message('boundary-observation');
 assert.equal(observation.factoryCalls,1);assert.equal(observation.bootCalls,1);assert.equal(observation.stopCalls,1);assert.equal(observation.drainCalls,1);
 assert.equal(observation.status.operationSettled,true);assert.equal(observation.status.ownership.bootPending,false);assert.equal(observation.status.ownership.listening,true);
 assert.equal(observation.status.retentionUnverified,false);assert.equal(observation.status.state,'blocked');assert.ok(!x.messages.some(m=>m.type==='desktop-stopped'));
}));
test('partial acquired rejection retains listener and IPC disconnect does not close',()=>run('boot-error',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});const listener=await x.message('boundary-listener');await x.message('desktop-shutdown-blocked');
 assert.equal(await request(listener.port),503);x.c.disconnect();await sleep(200);assert.equal(x.alive(),true);assert.equal(await request(listener.port),503);
}));
test('READY with fulfilled drain cannot release on IPC disconnect',()=>run('ready-disconnect',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});const listener=await x.message('boundary-listener');await x.message('desktop-ready');x.c.disconnect();await sleep(200);
 assert.equal(x.alive(),true);assert.equal(await request(listener.port),503);
 const observation=JSON.parse(fs.readFileSync(path.join(x.dir,'boundary-observation.json')));
 assert.equal(observation.stopCalls,1);assert.equal(observation.drainCalls,0);assert.ok(!x.messages.some(m=>m.type==='desktop-stopped'));
}));
test('actual post-READY kernel transport error blocks clean release',()=>run('ready-fault',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});await x.message('boundary-listener');await x.message('desktop-ready');x.c.send({type:'boundary-fault-ready'});
 const fault=await x.message('boundary-fault');assert.equal(fault.ownership.faulted,true);assert.equal(fault.ownership.everListening,true);
 x.c.send({type:'desktop-shutdown',sessionId:x.credentials.sessionId,controlToken:x.credentials.controlToken});const blocked=await x.message('desktop-shutdown-blocked');
 assert.equal(blocked.cause,'TRANSPORT_RELEASE_UNVERIFIED');assert.equal(blocked.ownership.faulted,true);assert.equal(blocked.retentionUnverified,true);
 assert.equal(x.alive(),true);assert.ok(!x.messages.some(m=>m.type==='desktop-stopped'));
}));
test('actual appAdapter negative bind before product imports, kernel EPERM',()=>run('actual-negative',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});const proof=await x.message('desktop-not-acquired');assert.deepEqual(await x.ended,{code:1,signal:null});
 assert.equal(proof.ownership.everListening,false);assert.equal(proof.ownership.listening,false);assert.equal(proof.ownership.sockets,0);assert.equal(proof.ownership.productInvoked,false);assert.equal(proof.ownership.releaseConfirmed,true);
 assert.ok(!x.messages.some(m=>['desktop-ready','desktop-stopped'].includes(m.type)));assert.equal(fs.readFileSync(path.join(x.dir,'db/unopened-anchor'),'utf8'),'not SQLite, must never be opened');
},{actual:true}));
test('ordinary READY boundary successful close callback and natural exit, not full app closure',()=>run('normal-positive',async x=>{
 x.c.send({type:'desktop-init',...x.credentials});await x.message('boundary-listener');await x.message('desktop-ready');
 x.c.send({type:'desktop-shutdown',sessionId:x.credentials.sessionId,controlToken:x.credentials.controlToken});const stopped=await x.message('desktop-stopped');
 assert.equal(stopped.scope,'adapter-transport-only');assert.equal(stopped.allShutdownValidated,false);assert.deepEqual(await x.ended,{code:0,signal:null});
}));

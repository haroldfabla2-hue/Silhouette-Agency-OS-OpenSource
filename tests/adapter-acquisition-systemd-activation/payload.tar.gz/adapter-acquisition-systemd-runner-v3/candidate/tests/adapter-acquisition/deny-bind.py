"""NOT RUN. Linux real syscall fault, no method replacement or product stubs.
Refuses unsupported architecture or failed kernel filter; never silently skips.
Used only in a disposable child, NEVER in caller/user installation.
"""
import ctypes, os, platform, sys
if sys.platform != 'linux': raise SystemExit('Linux required, no skip-as-pass')
abi={'x86_64':(49,62,0xc000003e),'aarch64':(200,183,0xc00000b7)}.get(platform.machine())
number=abi[0] if abi else None
if number is None: raise SystemExit('unsupported architecture, no skip-as-pass')
with open(sys.argv[1],'rb') as executable: elf=executable.read(20)
if elf[:6]!=b'\x7fELF\x02\x01' or int.from_bytes(elf[18:20],'little')!=abi[1]: raise SystemExit('Node executable ABI mismatch')
class F(ctypes.Structure): _fields_=[('code',ctypes.c_ushort),('jt',ctypes.c_ubyte),('jf',ctypes.c_ubyte),('k',ctypes.c_uint)]
class P(ctypes.Structure): _fields_=[('len',ctypes.c_ushort),('filter',ctypes.POINTER(F))]
filters=(F*7)(F(0x20,0,0,4),F(0x15,1,0,abi[2]),F(0x06,0,0,0x80000000),F(0x20,0,0,0),F(0x15,0,1,number),F(0x06,0,0,0x00050001),F(0x06,0,0,0x7fff0000))
program=P(7,filters);libc=ctypes.CDLL(None,use_errno=True)
if libc.prctl(38,1,0,0,0)!=0 or libc.prctl(22,2,ctypes.byref(program),0,0)!=0: raise OSError(ctypes.get_errno(),'filter not installed')
os.execv(sys.argv[1],sys.argv[1:])

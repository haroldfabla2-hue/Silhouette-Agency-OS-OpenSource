// Source-only identity check, not authorization to execute. No compiler import
// until bytes of compiler, node/python, candidate and fallback match lock.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
exports.verify=()=>{
 const candidate=path.resolve(__dirname,'../..'),lock=JSON.parse(fs.readFileSync(path.join(candidate,'RUNTIME-LOCK.json')));
 const profile=JSON.parse(fs.readFileSync(path.join(candidate,'EXECUTION-PROFILE.json')));
 const originalLock=hash(path.join(candidate,'RUNTIME-LOCK.json'));
 if(originalLock!==profile.originalRuntimeLockSha256)throw Error('ORIGINAL_LOCK_MUTATED');
 const repo=process.env.ACQ_REPO_ROOT;if(!repo||!path.isAbsolute(repo))throw Error('absolute ACQ_REPO_ROOT required');
 if(process.platform!==profile.platform||process.arch!==profile.arch||hash(process.execPath)!==profile.nodeSha256)throw Error('NODE_IDENTITY_MISMATCH');
 const python=process.env.ACQ_PYTHON_PATH;if(python!==profile.pythonPath||hash(python)!==profile.pythonSha256)throw Error('PYTHON_IDENTITY_MISMATCH');
 if(hash('/lib/x86_64-linux-gnu/libc.so.6')!==profile.libcSha256)throw Error('LIBC_IDENTITY_MISMATCH');
 for(const [relative,digest]of Object.entries(lock.candidate))if(hash(path.join(candidate,relative))!==(relative==='tests/adapter-acquisition/verify-environment.cjs'?profile.verifierOverlaySha256:digest))throw Error('CANDIDATE_HASH_MISMATCH '+relative);
 for(const [relative,digest]of Object.entries(lock.fallback))if(hash(path.join(candidate,'tests/adapter-acquisition/baseline',relative))!==digest)throw Error('FALLBACK_HASH_MISMATCH '+relative);
 for(const [relative,digest]of Object.entries(lock.compiler))if(hash(path.join(repo,relative))!==digest)throw Error('COMPILER_HASH_MISMATCH '+relative);
 return lock;
};

// Complete prepareActualAppAdapter + ownDesktopBackend call, no product factory
// or DB method substitution. The dummy DB is never parsed/opened as SQLite.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
(async()=>{
 const candidate=process.env.ACQ_CANDIDATE_ROOT;
 const {prepareActualAppAdapter}=await import(path.join(candidate,'server/desktop/appAdapter.ts'));
 const {ownDesktopBackend}=await import(path.join(candidate,'server/desktop/ownedBackendSession.js'));
 const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
 fs.mkdirSync('db');fs.writeFileSync('silhouette.config.json','{}');fs.writeFileSync('db/unopened-anchor','not SQLite, must never be opened');
 const identity=p=>{const s=fs.statSync(p);return {path:p,dev:String(s.dev),ino:String(s.ino)}};
 const root=fs.realpathSync(process.cwd()),s=fs.statSync(root);
 const descriptor={cwd:root,dev:String(s.dev),ino:String(s.ino),environmentSha256:hash(JSON.stringify(Object.keys(process.env).sort().map(k=>[k,process.env[k]]))),database:identity(path.join(root,'db/unopened-anchor')),existing:[{...identity(path.join(root,'silhouette.config.json')),kind:'file',sha256:hash('{}')},{...identity(path.join(root,'db')),kind:'directory'}]};
 const openBackend=prepareActualAppAdapter(descriptor,hash(JSON.stringify(descriptor)));
 await ownDesktopBackend({openBackend,handshakeMs:1500,bootMs:1500,shutdownMs:1500,sendMs:100});
 process.send({type:'boundary-start'});
})().catch(()=>{process.exitCode=99;if(process.connected)process.disconnect()});

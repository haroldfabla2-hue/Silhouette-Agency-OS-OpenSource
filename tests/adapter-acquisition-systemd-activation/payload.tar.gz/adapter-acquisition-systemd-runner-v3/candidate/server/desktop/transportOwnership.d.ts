import type { Server } from 'node:http';
export type TransportOwnership = Readonly<{
    version: 1; everListening: boolean; listening: boolean; sockets: number;
    productInvoked: boolean; bootPending: boolean; bindSettled: boolean;
    bindFailed: boolean; releaseConfirmed: boolean; faulted: boolean;
    retention: 'listener' | 'sockets' | 'unverified';
}>;
export type Acquisition = Readonly<{kind: 'not-acquired' | 'acquired' | 'ownership-unknown'; ownership: TransportOwnership}>;
export function createTransportOwnership(server: Server, onFault?: () => void): Readonly<{
    snapshot(): TransportOwnership; bind(host?: string, port?: number): Promise<Acquisition>;
    boot<T>(factory: () => T | Promise<T>): Promise<T>; noAcquisitionConfirmed(): boolean;
}>;
export function readTransportOwnership(value: unknown): TransportOwnership | null;
export function confirmsNoAcquisition(value: unknown): boolean;

// Actual transport owner used by the opt-in app adapter. No product imports,
// timers or auth changes. Error subscription is installed before listen.
export function createTransportOwnership(server, onFault = () => {}) {
    const sockets = new Set();
    let everListening = false, productInvoked = false, bootPending = false;
    let bindSettled = false, bindFailed = false, releaseConfirmed = false;
    let faulted = false, bindTask, bootTask;
    server.on('connection', socket => {
        sockets.add(socket); socket.once('close', () => sockets.delete(socket));
    });
    server.on('listening', () => { everListening = true; });
    // Permanent, never removed while imports/boot are in flight.
    server.on('error', () => {
        faulted = true;
        try { onFault(); } catch { /* caller diagnostic must not erase owner */ }
    });
    const snapshot = () => Object.freeze({
        version: 1, everListening, listening: server.listening,
        sockets: sockets.size, productInvoked, bootPending,
        bindSettled, bindFailed, releaseConfirmed, faulted,
        retention: server.listening ? 'listener' : sockets.size ? 'sockets' : 'unverified'
    });
    const notAcquired = () => {
        const s = snapshot();
        return s.bindSettled && s.bindFailed && !s.everListening && !s.listening
            && s.sockets === 0 && !s.productInvoked && !s.bootPending && s.releaseConfirmed;
    };
    return Object.freeze({
        snapshot,
        bind(host = '127.0.0.1', port = 0) {
            if (bindTask) return bindTask;
            if (host !== '127.0.0.1' || !Number.isSafeInteger(port) || port < 0 || port > 65535) throw new Error('OWNED_BIND_INVALID');
            bindTask = new Promise(resolve => {
                const failed = () => {
                    server.removeListener('listening', ready);
                    bindFailed = true;
                    // close() completion is observed even for never-running.
                    // ERR_SERVER_NOT_RUNNING is valid ONLY with no historical
                    // listen, no sockets, no product invocation as checked below.
                    server.close(error => {
                        releaseConfirmed = !error || (error.code === 'ERR_SERVER_NOT_RUNNING' && !everListening && sockets.size === 0 && !productInvoked);
                        bindSettled = true;
                        resolve({kind: notAcquired() ? 'not-acquired' : 'ownership-unknown', ownership: snapshot()});
                    });
                };
                const ready = () => {
                    server.removeListener('error', failed);
                    bindSettled = true;
                    resolve({kind: 'acquired', ownership: snapshot()});
                };
                server.once('error', failed); server.once('listening', ready);
                try { server.listen(port, host); } catch { server.removeListener('error', failed); failed(); }
            });
            return bindTask;
        },
        boot(factory) {
            if (bootTask) return bootTask;
            if (!bindSettled || bindFailed || !server.listening || faulted || typeof factory !== 'function') return Promise.reject(new Error('OWNED_TRANSPORT_NOT_READY'));
            productInvoked = true; bootPending = true;
            bootTask = Promise.resolve().then(factory).finally(() => { bootPending = false; });
            // Retained actual operation; caller still receives original reject.
            void bootTask.catch(() => {});
            return bootTask;
        },
        noAcquisitionConfirmed: notAcquired
    });
}
// Strict cross-module snapshot schema, not authorship or external permission.
export function readTransportOwnership(value) {
    const keys = ['version','everListening','listening','sockets','productInvoked','bootPending','bindSettled','bindFailed','releaseConfirmed','faulted','retention'];
    if (!value || typeof value !== 'object' || value.version !== 1
        || !['everListening','listening','productInvoked','bootPending','bindSettled','bindFailed','releaseConfirmed','faulted'].every(k => typeof value[k] === 'boolean')
        || !Number.isSafeInteger(value.sockets) || value.sockets < 0
        || !['listener','sockets','unverified'].includes(value.retention)
        || value.listening && !value.everListening
        || value.bootPending && !value.productInvoked
        || value.retention !== (value.listening ? 'listener' : value.sockets ? 'sockets' : 'unverified')
        || Object.keys(value).some(key => !keys.includes(key))) return null;
    return Object.freeze(Object.fromEntries(keys.map(key => [key, value[key]])));
}
export function confirmsNoAcquisition(value) {
    const s = readTransportOwnership(value);
    return !!s && s.bindSettled && s.bindFailed && s.releaseConfirmed && !s.everListening
        && !s.listening && s.sockets === 0 && !s.productInvoked && !s.bootPending;
}

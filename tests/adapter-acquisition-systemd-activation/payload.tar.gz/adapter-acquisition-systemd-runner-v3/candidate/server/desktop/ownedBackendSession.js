import { readTransportOwnership, confirmsNoAcquisition } from './transportOwnership.js';
// Opt-in backend lifecycle. UNSELECTED by CLI/build/Electron until data/runtime
// adapter review. Importing this file does not open stores or start services.
import { timingSafeEqual } from 'node:crypto';
let sessionClaimed = false;
const hex64 = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const same = (a, b) => hex64(a) && timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));

/** Trusted opt-in adapter only. Actual acquisition output must be inspected;
 * invocation/rejection alone cannot establish that no resource was acquired.
 * Acquired/unknown boot and drain retain ownership past diagnostic deadlines.
 * This boundary does not certify whole-product writer closure or recovery.
 */
export async function ownDesktopBackend({ openBackend, handshakeMs = 5000, bootMs = 30000, shutdownMs = 10000, sendMs = 250 }) {
    if (typeof process.send !== 'function' || !process.connected) throw new Error('DESKTOP_IPC_REQUIRED');
    if (typeof openBackend !== 'function') throw new Error('DESKTOP_ADAPTER_REQUIRED');
    if (sessionClaimed) throw new Error('DESKTOP_SESSION_ALREADY_OWNED');
    for (const ms of [handshakeMs, bootMs, shutdownMs, sendMs]) {
        if (!Number.isSafeInteger(ms) || ms < 1 || ms > 300000) throw new Error('DESKTOP_DEADLINE_INVALID');
    }
    sessionClaimed = true;
    let state = 'handshake', credentials, backend, stopping, handshakeTimer, bootTimer;
    let terminalFailure = false, deadlineExpired = false, stoppedDuringBoot = false, ownerLost = false;
    let adapterInvoked = false, operationSettled = false, stopDeadline, inspectOwnership;
    let stopCause = null;
    const status = () => {
        let ownership = null;
        try { ownership = readTransportOwnership((backend?.ownership || inspectOwnership)?.()); } catch { /* unknown remains unknown */ }
        return Object.freeze({state, cause: stopCause, operationSettled,
            ownership, retentionUnverified: !ownership || ownership.retention === 'unverified',
            debt: 'unknown', allShutdownValidated: false});
    };
    const failed = () => { terminalFailure = true; };
    const send = message => new Promise(resolve => {
        if (!process.connected) { resolve(false); return; }
        let done = false;
        const end = ok => { if (done) return; done = true; clearTimeout(timer); resolve(ok); };
        const timer = setTimeout(() => end(false), sendMs);
        try { process.send(message, error => end(!error)); } catch { end(false); }
    });
    const closeServer = server => new Promise((resolve, reject) => {
        try { server.close(error => error ? reject(new Error('DESKTOP_CLOSE_FAILED')) : resolve()); }
        catch { reject(new Error('DESKTOP_CLOSE_FAILED')); }
    });
    const blocked = async cause => {
        state = 'blocked'; stopCause = cause;
        const current = status();
        // Delivery is best effort only; disconnected IPC never grants release.
        await send({type: 'desktop-shutdown-blocked', sessionId: credentials?.sessionId, ...current});
        process.stderr.write('[DESKTOP] SHUTDOWN_BLOCKED_NO_DURABLE_RECOVERY\n');
        return current;
    };
    const finishNeverAcquired = async () => {
        state = 'not-acquired'; stopCause = 'NO_ACQUISITION_CONFIRMED';
        clearTimeout(stopDeadline);
        await send({type: 'desktop-not-acquired', sessionId: credentials?.sessionId, ...status()});
        // No owned transport/product was acquired. Permit natural failure
        // termination, not an artificial retained process for bad handshake.
        process.exitCode = 1;
        if (process.connected) process.disconnect();
        return status();
    };
    const stop = reason => {
        if (reason === 'owner-disconnected' || reason === 'ipc-error' || reason === 'ipc-send-failed') ownerLost = true;
        clearTimeout(handshakeTimer); clearTimeout(bootTimer);
        if (stopping) return stopping;
        stoppedDuringBoot = state === 'booting';
        state = 'draining'; stopCause = reason;
        stopDeadline = setTimeout(() => { deadlineExpired = true; void blocked('DRAIN_DEADLINE'); }, shutdownMs);
        // Retain this operation even after the diagnostic deadline. Repeated
        // signals join it. A late result updates status rather than replaying.
        stopping = Promise.resolve().then(async () => {
            if (!adapterInvoked && !bootPromise) return await finishNeverAcquired();
            if (bootPromise) await bootPromise;
            let ownership = null;
            try { ownership = backend?.ownership?.(); } catch { /* unverified */ }
            if (backend?.acquisition === 'not-acquired' && confirmsNoAcquisition(ownership)) return await finishNeverAcquired();
            if (!backend || typeof backend.stopAdmission !== 'function' || typeof backend.drain !== 'function') return await blocked('ACQUISITION_UNKNOWN');
            await backend.stopAdmission();
            if (ownerLost) return await blocked('OWNER_DISCONNECTED_RETAINED');
            const beforeDrain = status().ownership;
            if (!beforeDrain || beforeDrain.faulted) return await blocked('TRANSPORT_RELEASE_UNVERIFIED');
            await backend.drain();
            // Do not turn a late stop-during-boot or failure into permission
            // to release. Ordinary ready -> successful drain keeps its original
            // transport close path, rather than unconditional blocked replacement.
            if (stoppedDuringBoot || deadlineExpired || terminalFailure || ownerLost) return await blocked('LATE_FAILED_OR_DISCONNECTED_STOP_RETAINED');
            const beforeRelease = status().ownership;
            if (!beforeRelease || beforeRelease.faulted || !beforeRelease.listening || !beforeRelease.everListening || !beforeRelease.productInvoked || beforeRelease.bootPending) return await blocked('TRANSPORT_RELEASE_UNVERIFIED');
            await closeServer(backend.server);
            if (ownerLost || deadlineExpired || terminalFailure || status().ownership?.faulted) return await blocked('RELEASE_COMPLETION_UNVERIFIED');
            state = 'stopped'; clearTimeout(stopDeadline);
            const expectedReceipt = process.connected;
            const delivered = await send({type: 'desktop-stopped', sessionId: credentials?.sessionId, reason,
                clean: true, scope: 'adapter-transport-only', allShutdownValidated: false});
            if (expectedReceipt && !delivered) process.exitCode = 1;
            if (process.connected) process.disconnect();
            return status();
        }).catch(() => blocked('BOOT_OR_DRAIN_REJECTED')).finally(() => {
            operationSettled = true; clearTimeout(stopDeadline);
        });
        return stopping;
    };
    let bootPromise;
    const boot = async () => {
        try {
            // No env, cwd, data-path or CLI-token precedence changes here.
            adapterInvoked = true;
            backend = await openBackend(Object.freeze({ host: '127.0.0.1', port: 0, apiToken: credentials.apiToken,
                onOwnership: inspect => { if (typeof inspect === 'function' && !inspectOwnership) inspectOwnership = inspect; } }));
            if (backend?.acquisition === 'not-acquired' && confirmsNoAcquisition(backend?.ownership?.())) {
                clearTimeout(bootTimer); setImmediate(() => { void stop('bind-not-acquired'); }); return;
            }
            if (!backend || typeof backend.drain !== 'function' || typeof backend.stopAdmission !== 'function' || !backend.server || backend.authenticationReady !== true) throw new Error('invalid adapter');
            const address = backend.server.address();
            if (!address || typeof address === 'string' || address.address !== '127.0.0.1' || !Number.isInteger(address.port) || address.port < 1 || address.port > 65535) throw new Error('invalid bind');
            clearTimeout(bootTimer);
            if (state !== 'booting') return;
            state = 'ready';
            if (!await send({ type: 'desktop-ready', sessionId: credentials.sessionId, host: '127.0.0.1', port: address.port, pid: process.pid })) { failed(); void stop('ipc-send-failed'); }
        } catch {
            failed(); clearTimeout(bootTimer);
            // Never forward adapter errors, stack, paths, token or provider data.
            await send({ type: 'desktop-failed', code: 'BOOT_FAILED', sessionId: credentials.sessionId });
            // Schedule outside bootPromise to avoid self-await deadlock.
            setImmediate(() => { void stop('boot-failed'); });
        }
    };
    const onMessage = message => {
        if (!message || typeof message !== 'object') return;
        if (state === 'handshake') {
            if (message.type !== 'desktop-init' || !hex64(message.sessionId) || !hex64(message.controlToken) || !hex64(message.apiToken)) return;
            if (new Set([message.sessionId, message.controlToken, message.apiToken]).size !== 3) return;
            credentials = { sessionId: message.sessionId, controlToken: message.controlToken, apiToken: message.apiToken };
            clearTimeout(handshakeTimer); state = 'booting';
            bootTimer = setTimeout(() => { failed(); void stop('boot-timeout-partial-unresolved'); }, bootMs);
            bootPromise = boot();
            return;
        }
        if (message.type === 'desktop-shutdown' && credentials && same(message.sessionId, credentials.sessionId) && same(message.controlToken, credentials.controlToken)) void stop('owner-request');
    };
    process.on('message', onMessage);
    process.once('disconnect', () => { void stop('owner-disconnected'); });
    // Catch send-channel errors immediately. Not an error-message disclosure path.
    process.on('error', () => { failed(); void stop('ipc-error'); });
    process.on('SIGTERM', () => { void stop('signal'); });
    process.on('SIGINT', () => { void stop('signal'); });
    handshakeTimer = setTimeout(() => { failed(); void stop('handshake-timeout'); }, handshakeMs);
    return Object.freeze({ state: () => state, status });
}

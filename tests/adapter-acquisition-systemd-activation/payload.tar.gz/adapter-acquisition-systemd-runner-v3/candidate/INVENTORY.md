# Retained source ledger, not closure certificate

Exact baseline cd0066be67748f5948515bf3d20e6edc36d7b7c0. Chosen next inventory target is native server/index.ts server mode with optional started-resource binding absent. This is a partial ledger of observed gaps, not an exhaustive acquisition table. No normal full-app no-debt exit proven. Parent priority is finishing adapter/session first; no cost writer patch opened.

| Source match | Actual retained edge / gap |
| --- | --- |
| `server/loaders/dbLoader.ts:33,42,48,70,80` | Graph connect is raced with loader deadline; registration after awaited result leaves late acquisition outside completed loader. Actual driver ownership unresolved. |
| `services/graphService.ts:49` | Driver creation/replacement and verify failure cleanup need local ownership. Detached schema continuation, idle disconnect and concurrent connects remain gaps; close promise alone is not producer fence. |
| `services/daemon/unifiedDaemon.ts:161,180` | Unbound stop does not retain saveState completion. Concurrent ticks/save to shared tmp and absorbed unbound failures remain gaps; restart caller is separate. |
| `services/introspectionEngine.ts:613` | Store import/continuation is detached from outer admission. Z3 recent thoughts and nested Narrative coherence are additional downstream writers with incomplete returned promise lineage. |
| `services/dreamerService.ts:22,374` | Nested graph and semantic-memory writes are not returned; introspection updates and startup/scheduled continuations can outlive parent tickets and emit downstream work. |
| `server/jobs/persistence.ts:4,9,13,18` | Bound fanout retains workflow/orchestrator/continuum calls. Unbound periodic callbacks do not own all returned work or exported local stop. |
| `server/jobs/costPersistence.ts:8,20` | Next writer only, no patch now. Existing callback is synchronous JSON then SQLite with caught errors; interval has no exported stop receipt. Must fence before final metrics and preserve real failures; SQLite dependency remains. |
| `server/app.ts:217` | Actual native entry initServer promise is not necessarily awaited by index listen initialization; async acquisition can outlive apparent entry readiness. |
| `server/backendServices.ts:1,26,50,83,110` | Optional registry carries hooks only when bound; unbound no-op is a GAP, not a resource owner or full startup inventory. |
| `cli/commands/start.ts:128,136` | Native CLI timeout/parent exit is a different retention boundary from opt-in owned session; no exclusivity/cleanup claim transferred. |
| `cli/commands/restart.ts:44,45,49,52` | Restart kill boundary remains unchanged, no RAM debt transfer or safe quit claim. |
| `electron.cjs:178` | Packaged/dev process topology and Windows taskkill remain selected parent behavior, unmodified and outside opt-in acquisition guarantee. |

Outstanding before native no-debt proof: USER_MESSAGE subscriber promise lineage; resourceArbiter grants and post-grant descendants; Narrative emitter/journal and active Power callback quiescence; all real acquisition handles and registration binding/settle/close-error callbacks; graph driver cleanup; daemon save serialization. Existing findings are not fixed by the transport boundary.

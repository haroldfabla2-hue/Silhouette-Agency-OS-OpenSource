"""INACTIVE. Adapt existing reviewed systemd route, no new containment framework.
Only explicit run() after final source/context review. No executable CLI.
"""
from pathlib import Path
import hashlib,importlib.util,json,os,re,secrets,stat,time
HERE=Path(__file__).resolve().parent
EXPECTED_MODES={'normal':(False,1),'bind-fail':(False,1),'late-boot':(True,-9),'boot-error':(True,-9),'ready-disconnect':(True,-9),'ready-fault':(True,-9),'actual-negative':(False,1),'normal-positive':(False,0)}
EXPECTED_TEST_NAMES=[
 'never invoked adapter permits natural handshake failure exit',
 'actual owner bind conflict proves no product invocation and exits naturally',
 'acquired listener survives stop deadline, late boot updates and repeated signals join',
 'partial acquired rejection retains listener and IPC disconnect does not close',
 'READY with fulfilled drain cannot release on IPC disconnect',
 'actual post-READY kernel transport error blocks clean release',
 'actual appAdapter negative bind before product imports, kernel EPERM',
 'ordinary READY boundary successful close callback and natural exit, not full app closure']
def need(ok,code):
    if not ok:raise RuntimeError(code)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_source(path,name,wanted):
    need(sha(path)==wanted,'REUSE_SOURCE_PIN')
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def verify_local(review_manifest_sha):
    need(sha(HERE/'SHA256.json')==review_manifest_sha,'REVIEW_MANIFEST_PIN')
    rows=json.loads((HERE/'SHA256.json').read_text())
    for relative,wanted in rows.items():
        p=HERE/relative;need(not p.is_symlink() and p.is_file() and sha(p)==wanted,'REVIEW_PAYLOAD_PIN')

def add_exact(root):
    additions=json.loads((HERE/'ADAPTER-ROOTFS-ADDITIONS.json').read_text())
    for row in additions:
        target=Path(row['target']);need(target.is_absolute() and '..' not in target.parts,'ADDITION_PATH')
        need(target.parts[1] in ('candidate','compiler'),'ADDITION_PREFIX')
        source=HERE/str(target).lstrip('/');dest=root/str(target).lstrip('/')
        need(not dest.exists() and not source.is_symlink() and source.is_file(),'ADDITION_SOURCE_TYPE')
        need(source.stat().st_size==row['bytes'] and sha(source)==row['sha256'],'ADDITION_HASH')
        dest.parent.mkdir(mode=0o755,parents=True,exist_ok=True);dest.write_bytes(source.read_bytes());dest.chmod(row['mode'])
    rows=json.loads((HERE/'ADAPTER-SYSTEMD-ROOTFS.json').read_text());need(len(rows)==6011,'DERIVED_ROW_COUNT')
    need(len({x['target'] for x in rows})==len(rows),'DERIVED_DUPLICATES')
    for row in rows:
        p=root/row['target'].lstrip('/');need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'FINAL_ROOTFS_PIN')
    actual={'/'+p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};need(actual=={r['target'] for r in rows},'ROOTFS_EXTRA_OR_MISSING')

def inspect_case_receipts(work):
    directory=work/'evidence';need(directory.is_dir() and not directory.is_symlink(),'CASE_EVIDENCE_MISSING')
    files=list(directory.iterdir());need(len(files)==8,'CASE_RECEIPT_COUNT');seen=set();result=[]
    for path in files:
        need(path.is_file() and not path.is_symlink() and path.stat().st_size<=16384,'CASE_RECEIPT_BOUND')
        value=json.loads(path.read_text());mode=value.get('mode');need(mode in EXPECTED_MODES and mode not in seen,'CASE_MODE_SET');seen.add(mode)
        need(value.get('watchdogFired') is False and value.get('overflowFired') is False and value.get('reapTimedOut') is False and value.get('reaped') is True and value.get('spawnError') is None,'CASE_UNEXPECTED_TERMINATION')
        need(value.get('allShutdownValidated') is False and type(value.get('outputBytes')) is int and value['outputBytes']<=65536,'CASE_SCOPE_OR_OUTPUT')
        expected_forced,code=EXPECTED_MODES[mode];need(value.get('cleanupForced') is expected_forced and value.get('naturalExit') is (not expected_forced),'CASE_CLEANUP_CLASSIFICATION')
        exit=value.get('exit');need(isinstance(exit,dict),'CASE_EXIT_MISSING')
        kills=value.get('killRequests');need(isinstance(kills,list),'CASE_KILL_SCHEMA')
        if expected_forced:
            need(exit.get('code') is None and exit.get('signal')=='SIGKILL' and len(kills)==1 and kills[0].get('cause')=='expected-negative-or-failed-test-cleanup' and kills[0].get('requested') is True and kills[0].get('accepted') is True,'EXPECTED_NEGATIVE_CLEANUP_MISSING')
        else:need(exit.get('code')==code and exit.get('signal') is None and kills==[],'NATURAL_CASE_NOT_NATURAL')
        result.append({'mode':mode,'receiptSha256':sha(path),'expectedForcedCleanup':expected_forced,'naturalExit':not expected_forced,'exitCode':exit.get('code'),'signal':exit.get('signal'),'watchdogFired':False,'overflowFired':False,'reaped':True,'allShutdownValidated':False})
    need(seen==set(EXPECTED_MODES),'CASE_MISSING');return sorted(result,key=lambda x:x['mode'])

def inspect_tap(log):
    need(log.is_file() and log.stat().st_size<=1048576,'BATCH_LOG_BOUND')
    lines=log.read_text().splitlines()
    meta_lines=[line[2:] if line.startswith('# ') else line for line in lines]
    ok=[line for line in lines if re.fullmatch(r'ok [1-8] - .+',line)]
    need(ok==['ok '+str(i+1)+' - '+name for i,name in enumerate(EXPECTED_TEST_NAMES)],'TAP_EIGHT_EXACT_TESTS')
    need(not any(re.match(r'not ok\b',line) for line in lines),'TAP_FAILURE')
    for summary in ('1..8','# tests 8','# suites 0','# pass 8','# fail 0','# cancelled 0','# skipped 0','# todo 0'):need(lines.count(summary)==1,'TAP_SUMMARY_MISMATCH')
    metadata=[json.loads(line.removeprefix('ADAPTER_RUNTIME_META ')) for line in meta_lines if line.startswith('ADAPTER_RUNTIME_META ')]
    need(1<=len(metadata)<=16 and all(v.get('kind')=='NODE' and v.get('platform')=='linux' and v.get('arch')=='x64' and isinstance(v.get('node'),str) and isinstance(v.get('kernel'),str) for v in metadata),'RUNTIME_METADATA_INVALID')
    python=[json.loads(line.removeprefix('ADAPTER_PYTHON_META ')) for line in meta_lines if line.startswith('ADAPTER_PYTHON_META ')]
    need(len(python)==1 and isinstance(python[0].get('python'),str) and isinstance(python[0].get('kernel'),str),'PYTHON_METADATA_INVALID')
    return {'runtimeMetadata':metadata,'pythonMetadata':python[0],'sha256':sha(log),'bytes':log.stat().st_size,'tests':8,'pass':8,'fail':0,'skipped':0,'scope':'BOUNDARY_ONLY_NOT_FULL_APPLICATION'}

def require_types(receipt,wanted_sha):
    need(receipt.is_file() and not receipt.is_symlink() and receipt.stat().st_size<=16384,'TYPES_RECEIPT_BOUND');need(sha(receipt)==wanted_sha,'TYPES_RECEIPT_IDENTITY');value=json.loads(receipt.read_text())
    need(value.get('state')=='PASSED' and value.get('fullRepositoryTypesPassed') is True and value.get('typesExitCode')==0 and value.get('installExitCode')==0,'REAL_TYPES_NOT_PASSED')
    need(value.get('productExecuted') is False and value.get('nativeAddonsExecuted') is False and value.get('lifecycleScriptsEnabled') is False,'TYPES_SCOPE')
    need(value.get('packageLockSha256')=='f8cad2766f4c9d32310625e8951a53f17355c94409424aeb917e6ad5c01e9512' and value.get('adapterCandidateArchiveSha256')=='7de96b7e6e90bdc47ed22ae5b3306e78c142ff7c8873d60021c9e1788d8fec66' and value.get('sourceBaseline')=='cd0066be67748f5948515bf3d20e6edc36d7b7c0','TYPES_SOURCE_BINDING')
    need(value.get('lockBeforeSha256')==value.get('lockAfterSha256')==value.get('packageLockSha256') and value.get('compilerVersion')=='5.8.3' and value.get('nodeTypesVersion')=='22.19.1' and value.get('compilerSha256')=='2cffde0b8c6760dfb0b5b0382bbb7e00ba6a8b2d981b9205b256a700a481d983','TYPES_DEPENDENCY_OR_LOCK_IDENTITY')
    need(value.get('candidatePatchSha256')==sha(HERE/'candidate/candidate.patch'),'TYPES_PATCH_IDENTITY')
    return {'receiptSha256':sha(receipt),'fullRepositoryTypesPassed':True,'compilerVersion':value.get('compilerVersion'),'compilerSha256':value.get('compilerSha256')}

def prove_failed_cleanup_empty(control_group):
    # Read only the exact owned unit's cgroup subtree. This is failed-cleanup
    # evidence, not product process discovery or a substitute success oracle.
    need(isinstance(control_group,str) and re.fullmatch(r'/system.slice/adapter-acquisition-[a-f0-9]{16}\.service',control_group),'CLEANUP_CGROUP_PATH')
    root=Path('/sys/fs/cgroup')/control_group.lstrip('/')
    need(root.is_dir() and not root.is_symlink(),'CLEANUP_CGROUP_DISAPPEARED')
    def events():
        path=root/'cgroup.events';need(path.is_file() and path.stat().st_size<=4096,'CLEANUP_EVENTS_BOUND')
        with path.open() as stream:raw=stream.read(4097)
        need(len(raw)<=4096,'CLEANUP_EVENTS_OVERFLOW');rows=dict(line.split() for line in raw.splitlines());need(rows.get('populated')=='0','CLEANUP_CGROUP_POPULATED');return rows
    before=events();directories=[root];count=0
    while directories:
        directory=directories.pop();count+=1;need(count<=128,'CLEANUP_CGROUP_SUBTREE_BOUND');need(directory.is_dir() and not directory.is_symlink(),'CLEANUP_SUBTREE_CHANGED')
        procs=directory/'cgroup.procs'
        with procs.open() as stream:raw=stream.read(4097)
        need(len(raw)<=4096 and not raw.strip(),'CLEANUP_DESCENDANTS_PRESENT')
        for child in directory.iterdir():
            need(not child.is_symlink(),'CLEANUP_CGROUP_SYMLINK')
            if child.is_dir():directories.append(child)
    after=events();need(root.is_dir(),'CLEANUP_CGROUP_DISAPPEARED')
    return {'controlGroup':control_group,'populatedBefore':before['populated'],'populatedAfter':after['populated'],'recursiveProcsEmpty':True,'directoriesChecked':count,'observedBeforeUnmount':True}

def run(*,repository,archive,manifest,context_module,expected_context,receipt,review_manifest_sha,types_receipt,types_receipt_sha):
    repository=Path(repository);receipt=Path(receipt);result={'kind':'ADAPTER_ACQUISITION_SYSTEMD_EIGHT_CASES','result':'UNKNOWN','batchAttempted':False,'allShutdownValidated':False,'fullApplicationValidated':False,'forcedOuterCleanup':False,'ownedUnits':[]}
    verify_local(review_manifest_sha)
    pins=json.loads((HERE/'REUSE-PINS.json').read_text())
    old=load_source(repository/'tests/narrative-direct-systemd/direct-services.INACTIVE.py','reviewed_systemd_runner',pins['tests/narrative-direct-systemd/direct-services.INACTIVE.py'])
    base=Path('/tmp')/('adapter-direct-'+secrets.token_hex(8));mounted=[];unit=None;stopped=True
    try:
        need(os.geteuid()==0,'ROOT_MANAGER_REQUIRED')
        guard=HERE/'source-guard.INACTIVE.py';spec=importlib.util.spec_from_file_location('root_transitive_guard',guard);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);result['transitiveSource']=module.validate(repository)
        context=load_source(context_module,'reviewed_hosted_context',pins['tests/narrative-directed/context-snapshot.INACTIVE.py']).read_for_root('/tmp/narrative-directed-hosted-job.json',expected_context)
        need(Path.cwd().resolve()==repository.resolve(),'REPOSITORY_CWD_MISMATCH');need(old.command('/usr/bin/git','-C',str(repository),'rev-parse','HEAD')==context['eventHead'],'CONTEXT_HEAD_CHANGED');need(Path('/proc/1/comm').read_text().strip()=='systemd','HOST_MANAGER_REQUIRED');result['contextValidated']=True
        result['types']=require_types(Path(types_receipt),types_receipt_sha);old.durable(receipt,result)
        base.mkdir(mode=0o700);work=base/'work';tmp=base/'tmp';work.mkdir();tmp.mkdir()
        previous=repository/'tests/narrative-direct-systemd'
        root=old.extract_reviewed(archive,manifest,previous/'native-selection-guard.DIRECT-SYSTEMD.cjs',previous/'DIRECT-SYSTEMD-ROOTFS.json',base/'root');add_exact(root)
        for target,options in ((work,'size=33554432,nr_inodes=4096'),(tmp,'size=16777216,nr_inodes=2048')):
            old.command('/usr/bin/mount','-t','tmpfs','-o','rw,nosuid,nodev,noexec,'+options+',uid=1000,gid=1000,mode=0700','tmpfs',str(target));mounted.append(target)
        (work/'evidence').mkdir(mode=0o700);os.chown(work/'evidence',1000,1000)
        service=(HERE/'adapter-batch.service.INACTIVE').read_text()
        for key,path in (('@ROOT@',root),('@WORK@',work),('@TMP@',tmp)):
            need(re.fullmatch('/[A-Za-z0-9_./-]+',str(path)) is not None,'OWN_PATH_SYNTAX');service=service.replace(key,str(path))
        need('@' not in service,'SERVICE_PLACEHOLDER')
        unit='adapter-acquisition-'+secrets.token_hex(8)+'.service';file=Path('/run/systemd/system')/unit;need(not file.exists(),'OWN_UNIT_EXISTS');file.write_text(service);file.chmod(0o600)
        result['ownedUnits']=[unit];stopped=False;old.durable(receipt,result);old.command('/usr/bin/systemctl','daemon-reload')
        result['batchAttempted']=True;old.durable(receipt,result);old.command('/usr/bin/systemctl','start','--no-block',unit)
        until=time.monotonic()+50
        while time.monotonic()<until:
            state=old.unit_state(unit)
            extra=old.command('/usr/bin/systemctl','show',unit,'--property=RuntimeMaxUSec,TimeoutStartUSec,TimeoutStopUSec,OOMPolicy,MemoryOOMGroup,CapabilityBoundingSet,AmbientCapabilities,ProtectSystem,ProtectHome,ControlGroup')
            for line in extra.splitlines():
                key,value=line.split('=',1);state[key]=value
            result['lastUnitState']=state
            if state.get('ActiveState')=='failed':raise RuntimeError('ADAPTER_UNIT_FAILED')
            if state.get('ActiveState')=='active' and state.get('SubState')=='exited':break
            time.sleep(.2)
        else:raise RuntimeError('ADAPTER_UNIT_NOT_NATURALLY_EXITED')
        wanted={'Id':unit,'LoadState':'loaded','ActiveState':'active','SubState':'exited','Result':'success','ExecMainCode':'1','ExecMainStatus':'0','MainPID':'0','ControlPID':'0','Type':'exec','ExitType':'cgroup','RemainAfterExit':'yes','User':'1000','Group':'1000','RootDirectory':str(root),'PrivateNetwork':'yes','PrivateDevices':'yes','NoNewPrivileges':'yes','MemoryMax':'536870912','MemorySwapMax':'0','TasksMax':'64','CPUQuotaPerSecUSec':'1s','CPUQuotaPeriodUSec':'100ms','KillMode':'control-group','Restart':'no','RuntimeMaxUSec':'45s','TimeoutStartUSec':'5s','TimeoutStopUSec':'2s','OOMPolicy':'stop','MemoryOOMGroup':'yes','CapabilityBoundingSet':'','AmbientCapabilities':'','ProtectSystem':'strict','ProtectHome':'yes'}
        result['wantedUnitProperties']=wanted;old.durable(receipt,result)
        need(all(state.get(k)==v for k,v in wanted.items()),'ADAPTER_TERMINAL_PROPERTIES')
        need(isinstance(state.get('ControlGroup'),str) and state['ControlGroup'].startswith('/system.slice/adapter-acquisition-'),'ADAPTER_CGROUP_IDENTITY')
        result['cpuUnits']={'CPUQuotaSetting':'100%','CPUQuotaPerSecUSec':state.get('CPUQuotaPerSecUSec'),'CPUQuotaPeriodUSec':state.get('CPUQuotaPeriodUSec'),'effectiveKernelQuotaUSec':100000,'effectiveKernelPeriodUSec':100000}
        result['wantedUnitProperties']=wanted
        result['cases']=inspect_case_receipts(work);result['tap']=inspect_tap(tmp/'adapter-batch.log');result['managerReportedWholeCgroupExited']=True;result['scope']='EIGHT_BOUNDARY_CASES_NOT_FULL_APP';result['result']='PASS_ADAPTER_BOUNDARY_EIGHT_CASES_ONLY';old.durable(receipt,result)
        old.command('/usr/bin/systemctl','stop',unit);stopped=True;file.unlink();old.command('/usr/bin/systemctl','daemon-reload');result['ownedUnits']=[]
    except BaseException as error:
        result['failureClass']=type(error).__name__;text=str(error);result['failureCode']=text if re.fullmatch('[A-Z][A-Z0-9_]{0,95}',text) else 'UNCLASSIFIED_ADAPTER_FAILURE'
    finally:
        if not stopped and unit:
            result['forcedOuterCleanup']=True
            try:
                result['cleanupBeforeStopState']=old.unit_state(unit)
                cg=old.command('/usr/bin/systemctl','show',unit,'--property=ControlGroup','--value');result['cleanupControlGroup']=cg
                old.command('/usr/bin/systemctl','stop',unit,timeout=5);state=old.unit_state(unit);result['cleanupAfterStopState']=state
                need(state.get('ActiveState') in ('inactive','failed') and state.get('MainPID')=='0' and state.get('ControlPID')=='0','CLEANUP_STOP_UNCONFIRMED')
                result['cleanupCgroupEmpty']=prove_failed_cleanup_empty(cg);stopped=True
                file=Path('/run/systemd/system')/unit
                if file.exists():file.unlink()
                old.command('/usr/bin/systemctl','daemon-reload');result['ownedUnits']=[]
            except BaseException:result['cleanupUnknown']=True
        # Export public fixture receipts even on failed oracle, after stop only.
        if stopped:
            try:
                evidence=receipt.parent/'adapter-selected';evidence.mkdir(mode=0o700,exist_ok=True)
                for directory,glob,limit in ((base/'work/evidence','*.json',16384),(base/'tmp','adapter-batch.log',1048576)):
                    if not directory.is_dir():continue
                    paths=list(directory.glob(glob));need(len(paths)<=16,'EVIDENCE_COUNT_BOUND')
                    for path in paths:
                        if path.is_file() and not path.is_symlink():
                            with path.open('rb') as stream:raw=stream.read(limit+1)
                            (evidence/path.name).write_bytes(raw[:limit]);result.setdefault('exports',[]).append({'file':path.name,'bytes':min(len(raw),limit),'partial':len(raw)>limit})
                if any(v['partial'] for v in result.get('exports',[])):result['evidenceUnknown']=True
            except BaseException:result['evidenceUnknown']=True
            for path in reversed(mounted):
                try:old.command('/usr/bin/umount',str(path))
                except BaseException:result['cleanupUnknown']=True
        if result.get('evidenceUnknown'):result['result']='UNKNOWN';result['evidenceFailureCode']='EVIDENCE_UNVERIFIED'
        if result.get('cleanupUnknown'):result['result']='UNKNOWN';result['cleanupFailureCode']='CLEANUP_UNVERIFIED'
        if result['forcedOuterCleanup']:result['result']='UNKNOWN'
        result['temporaryRootRetainedUntilVMTeardown']=base.exists();old.durable(receipt,result)
    return result
if __name__=='__main__':raise SystemExit('INACTIVE: no execution/publication authority')
